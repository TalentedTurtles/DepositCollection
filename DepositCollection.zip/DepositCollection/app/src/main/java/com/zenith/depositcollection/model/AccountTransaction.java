package com.zenith.depositcollection.model;

import java.util.Date;

public class AccountTransaction

{

    long id = 0;

    String accountNo = "";

    String transactionDate;

    String particulars = "";

    String insNumber = "";

    String ins_date = "";

    String debit = "";

    String credit = "";

    String balance = "";

    String timeStamp = "";

    String comments = "";




    public AccountTransaction() {
        super();
        // TODO Auto-generated constructor stub
    }

    public AccountTransaction(String accountNo, String transactionDate,
                              String particulars,
                              String debit, String credit, String balance) {
        super();
        this.accountNo = accountNo;
        this.transactionDate = transactionDate;
        this.particulars = particulars;
       // this.insNumber = insNumber;
        //this.ins_date = ins_date;
        this.debit = debit;
        this.credit = credit;
        this.balance = balance;
       // this.timeStamp = timeStamp;
        //this.comments = comments;
    }





    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getParticulars() {
        return particulars;
    }

    public void setParticulars(String particulars) {
        this.particulars = particulars;
    }

    public String getInsNumber() {
        return insNumber;
    }

    public void setInsNumber(String insNumber) {
        this.insNumber = insNumber;
    }

    public String getIns_date() {
        return ins_date;
    }

    public void setIns_date(String ins_date) {
        this.ins_date = ins_date;
    }

    public String getDebit() {
        return debit;
    }

    public void setDebit(String debit) {
        this.debit = debit;
    }

    public String getCredit() {
        return credit;
    }

    public void setCredit(String credit) {
        this.credit = credit;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }



}
