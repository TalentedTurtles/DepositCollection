package com.zenith.depositcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import com.zenith.depositcollection.adapter.HomeView;
import com.zenith.depositcollection.adapter.HomeViewAdapter;
import com.zenith.depositcollection.asyncTask.AsyncCallWS;
import com.zenith.depositcollection.asyncTask.AsyncResponse;
import com.zenith.depositcollection.util.AppConstants;
import com.zenith.depositcollection.util.AppUtil;
import com.zenith.depositcollection.util.StringUtil;

import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity  implements AsyncResponse {

    GridView homeGrid;
    TextView collDate;
    TextView agentInfo;
    TextView lastLogin;
    SharedPreferences preferences;
    Boolean isFromLogin=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        homeGrid = findViewById(R.id.homeGridLayout);
        collDate = (TextView)findViewById(R.id.collectDateVal);
        agentInfo = (TextView)findViewById(R.id.agentNameVal);
        lastLogin= (TextView)findViewById(R.id.lastLoginVal);

        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        isFromLogin =   getIntent().getBooleanExtra(AppConstants.FROM_LOGIN,false);

        if(isFromLogin)
        {
            getAgentDetails();
        }
        else {
            setAgentDetail();
        }

        Date today = new Date();
        String dateStr = StringUtil.DateToString(today);
        collDate.setText(dateStr);
        Date loginDate = new Date();
        String dateLoginStr = StringUtil.DateToStringTime(loginDate);
        lastLogin.setText(dateLoginStr);

        ArrayList<HomeView> homeViewArrayList = new ArrayList<HomeView>();
        homeViewArrayList.add(new HomeView(getString(R.string.agentBal), R.drawable.agentbal));
        homeViewArrayList.add(new HomeView(getString(R.string.agentStatement), R.drawable.statement));
        homeViewArrayList.add(new HomeView(getString(R.string.duplicateReceipt), R.drawable.receipt));
        homeViewArrayList.add(new HomeView(getString(R.string.pigmyCollect), R.drawable.pigycollection));
        homeViewArrayList.add(new HomeView(getString(R.string.rdCollection), R.drawable.rdcollect));
        homeViewArrayList.add(new HomeView( getString(R.string.loanCollect),R.drawable.loan));
        homeViewArrayList.add(new HomeView( getString(R.string.collectionReport),R.drawable.report));
        homeViewArrayList.add(new HomeView( getString(R.string.masterDataSync),R.drawable.datasync));
        homeViewArrayList.add(new HomeView( getString(R.string.agentDataSync),R.drawable.agentsync));
        homeViewArrayList.add(new HomeView( getString(R.string.changePassword),R.drawable.changepass));
        homeViewArrayList.add(new HomeView( getString(R.string.btPrinter),R.drawable.btprint));



        HomeViewAdapter adapter = new HomeViewAdapter(this, homeViewArrayList);
        homeGrid.setAdapter(adapter);

        homeGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                switch (position) {
                    case 0:
                        Intent agentBal = new Intent(MainActivity.this,AgentBal.class);
                        startActivity(agentBal);
                        finish();
                        break;
                    case 1:
                        Intent agentStatement = new Intent(MainActivity.this,AgentStatement.class);
                        startActivity(agentStatement);
                        finish();
                        break;
                        case 2:
                        Intent duplicateRecipt = new Intent(MainActivity.this,DuplicateReceipt.class);
                        startActivity(duplicateRecipt);
                        finish();
                        break;
                    case 3:



                        Intent pigmyCollect = new Intent(MainActivity.this,Dashboard.class);
                        startActivity(pigmyCollect);
                        finish();
                        break;

                        case 4:
                        Intent rdCollect = new Intent(MainActivity.this,RdDashboard.class);
                        startActivity(rdCollect);
                        finish();
                        break;

                    case 5:
                        Intent loanCollect = new Intent(MainActivity.this, LoanDashboard.class);
                        startActivity(loanCollect);
                        finish();
                        break;
                    case 6:
                        Intent report = new Intent(MainActivity.this,CollectionReport.class);
                        startActivity(report);
                        finish();
                        break;
                    case 7:
                        Intent masterSync = new Intent(MainActivity.this,MasterSync.class);
                        startActivity(masterSync);
                        finish();
                        break;
                    case 8:
                        Intent agentSync = new Intent(MainActivity.this,AgentSync.class);
                        startActivity(agentSync);
                        finish();
                        break;

                    case 9:
                        Intent changePin = new Intent(MainActivity.this,ChangePin.class);
                        startActivity(changePin);
                        finish();
                        break;


                    case 10:
                        Intent btPrint = new Intent(MainActivity.this,BTPrint.class);
                        startActivity(btPrint);
                        finish();
                        break;

                    default:
                        break;

                }
            }
        });

        //Add Data


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.logout,menu);

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId())
        {

            case R.id.logoutBtn:

                showLogoutDialog(getResources().getString(R.string.alert_logout));

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    private void showLogoutDialog(String message)
    {
        final Dialog dialog = new Dialog(this);


//		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_two_btn_alert_dialog);

        dialog.setTitle(getString(R.string.logout));

        TextView textView = (TextView) dialog.findViewById(R.id.customAlert_text);

        Button cancelBtn = (Button) dialog.findViewById(R.id.cancel_btn);

        Button okBtn = (Button) dialog.findViewById(R.id.ok_btn);

        textView.setText(message);

        cancelBtn.setText(getString(R.string.no));
        okBtn.setText(getString(R.string.yes));


        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog.dismiss();

            }
        });

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                Intent intent = new Intent(MainActivity.this, Login.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });

        dialog.show();

    }


    @Override
    public void processAsyncResponse(Object output) {
        String responseXmlString = (String) output;
        Log.e("responseXmlString", responseXmlString);
        if (Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(responseXmlString))) == 0) {


            AppUtil.saveAgentDetails(responseXmlString,preferences,this);

            //String[] schemeTypes = AppUtil.getXpathValues("Result/Schemes/R/SubSysType", AppUtil.buildDocument(responseXmlString));
            //String[] schemeCodes = AppUtil.getXpathValues("Result/Schemes/R/SubSysCode", AppUtil.buildDocument(responseXmlString));


        }
        else {
            responseXmlString = AppUtil.getAgentDetails(preferences, this);


        }
        String agentNameValue = AppUtil.getXpathValue("Result/Details/AgentName", AppUtil.buildDocument(responseXmlString));
        String agentId = AppUtil.getCustomerID(preferences,this);
        String agentData="";
        if(agentNameValue != null)
        {
            agentData = agentNameValue+" - "+agentId;
        }else {
            agentData = agentId;
        }
        agentInfo.setText(agentData);


    }
    private void getAgentDetails()
    {


        String mobileNo = AppUtil.getMobileNumber(preferences,this);
        String imeiDeviceId = AppUtil.getDeviceIdentity(preferences,this);
        String tokenId=AppUtil.getToken(preferences,this);
        String agentId=AppUtil.getCustomerID(preferences,this);
        String input = "<Parameter><ProcessID>3101</ProcessID><MobileNo>"+mobileNo+"</MobileNo><IMEINo>"+imeiDeviceId+"</IMEINo><TokenID>"+tokenId+"</TokenID><AgentID>"+agentId+"</AgentID></Parameter>";
        Log.e("process id 3101",input);
        AsyncCallWS asyncCallWS = new AsyncCallWS(MainActivity.this, input,MainActivity.this);
        asyncCallWS.execute();
    }

 private  void setAgentDetail()
 {
     String responseXmlString = AppUtil.getAgentDetails(preferences, this);
     String agentNameValue = AppUtil.getXpathValue("Result/Details/AgentName", AppUtil.buildDocument(responseXmlString));
     String agentId = AppUtil.getCustomerID(preferences,this);
     String agentData="";
     if(agentNameValue != null)
     {
         agentData = agentNameValue+" - "+agentId;
     }else {
         agentData = agentId;
     }
     agentInfo.setText(agentData);

 }





}
