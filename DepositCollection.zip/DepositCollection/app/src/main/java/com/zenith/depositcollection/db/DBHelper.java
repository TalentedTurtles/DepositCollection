/********************************************************************************
 * DataBaseHelper.java   Mar 2, 2015
 *
 * Copyright (c) 2008 ZenithSoft.
 * The information contained in this document is the exclusive property of
 * Zenithsoft.  This work is protected under copyright laws of given countries of
 * origin and international laws, treaties and/or conventions.
 * No part of this document may be reproduced or transmitted in any form or by any means,
 * electronic or mechanical including photocopying or by any informational storage or
 * retrieval system, unless as expressly permitted by ZenithSoft.
 *
 * Modification History :
 * Name				Date					Description
 * ----				----					-----------
 * rsekhar			Mar 2, 2015					Created
 *******************************************************************************/
package com.zenith.depositcollection.db;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.DatabaseUtils;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Class : <<Description>>
 *
 * @version $ Revision: 1.0 $
 * @author rsekhar
 */
public class DBHelper extends SQLiteOpenHelper
{

    private static final String DATABASE_NAME = "depositCollectionDB";

    private static final int DATABASE_VERSION = 3;
    /**
     * Comment for <code>DBHelper</code>
     */
    public static DBHelper sDBHelper = null;

    /**
     * Comment for <code>tablesList</code>
     */
    private static List<String> sCreateTablesList;



    /**
     * Constructor : <<Description>>
     *
     * @param context
     */
    public DBHelper(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        //open();
    }

    /**
     * onCreate : <<Description>> (non-Javadoc)
     *
     * @see android.database.sqlite.SQLiteOpenHelper#onCreate(android.database.sqlite.SQLiteDatabase)
     */
    @Override
    public void onCreate(SQLiteDatabase database)
    {
        Log.i("DataBaseHelper", "new create");
        try
        {
            if (sCreateTablesList != null && !sCreateTablesList.isEmpty())
            {
                for (String create_table : sCreateTablesList)
                {
                    database.execSQL(create_table);
                }
            }

        }
        catch (Exception exception)
        {
            Log.e("DataBaseHelper", "Exception onCreate() exception");
        }

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS "+ DATABASE_NAME);
        onCreate(db);
    }





    /**
     * getDBInstance : <<Description>>
     *
     * @param context
     * @return
     */
    public static void intializeDBInstance(Context context, List<String> allTables)
    {
        if (sCreateTablesList == null)
        {
            sCreateTablesList = new ArrayList<String>();
            sCreateTablesList = allTables;
        }
        if (sDBHelper == null)
        {
            sDBHelper = new DBHelper(context);

        }

    }

    /**
     * open : <<Description>>
     *
     * @return
     * @throws SQLException
     */
    public static synchronized SQLiteDatabase open() throws SQLException
    {
        return sDBHelper.getWritableDatabase();
    }

    /*********************** Escape string for single quotes (Insert,Update) ************/
    public static String sqlEscapeString(String aString)
    {
        String aReturn = "";

        if (null != aString)
        {
            // aReturn = aString.replace("'", "''");
            aReturn = DatabaseUtils.sqlEscapeString(aString);
            // Remove the enclosing single quotes ...
            aReturn = aReturn.substring(1, aReturn.length() - 1);
        }

        return aReturn;
    }

    /*********************** UnEscape string for single quotes (show data) ************/
    private static String sqlUnEscapeString(String aString)
    {

        String aReturn = "";

        if (null != aString)
        {
            aReturn = aString.replace("''", "'");
        }

        return aReturn;
    }

}
