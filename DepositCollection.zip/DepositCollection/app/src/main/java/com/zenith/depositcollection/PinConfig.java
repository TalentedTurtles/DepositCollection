package com.zenith.depositcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.zenith.depositcollection.asyncTask.AsyncCallWS;
import com.zenith.depositcollection.asyncTask.AsyncResponse;
import com.zenith.depositcollection.util.AlertDialogueUtil;
import com.zenith.depositcollection.util.AppUtil;
import com.zenith.depositcollection.util.StringUtil;

public class PinConfig extends AppCompatActivity  implements AsyncResponse {
    Button doneBtn;
    Button resendOTPBtn;
    EditText otp;
    EditText mpin;
    EditText confirmMpin;
    String imeiDeviceId;
    String mobileNo="9663536715";
    String mpinNumber="";
    SharedPreferences preferences;
    String serviceName="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin_config);
        otp = (EditText)findViewById(R.id.otpEditTxt);
        mpin=(EditText)findViewById(R.id.mpinEditTxt);
        confirmMpin=(EditText)findViewById(R.id.confirmMpinEditTxt);
        resendOTPBtn=(Button)findViewById(R.id.resendOTPButton);
        preferences = PreferenceManager.getDefaultSharedPreferences(this);

        doneBtn = (Button)findViewById(R.id.doneButton);
        doneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!StringUtil.hasValue(otp.getText().toString()))
                {
                    otp.setError(getString(R.string.field_err_msg));
                    return;
                }
                if(!StringUtil.hasValue(mpin.getText().toString()))
                {
                    mpin.setError(getString(R.string.field_err_msg));
                    return;
                }

                if(!StringUtil.hasValue(confirmMpin.getText().toString()))
                {
                    confirmMpin.setError(getString(R.string.field_err_msg));
                    return;
                }
                if(!mpin.getText().toString().equals(confirmMpin.getText().toString()))
                 {
                    confirmMpin.setError(getString(R.string.mpin_err_msg));
                     return;
                  }
                mpinNumber = mpin.getText().toString();

                imeiDeviceId = AppUtil.getDeviceIdentity(preferences,PinConfig.this);


                registerMobileNumber();

            }
        });
        resendOTPBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                resendOTP();
            }
        });

    }

    @Override
    public void processAsyncResponse(Object output) {
        String responseXmlString = (String) output;
        Log.e("responseXmlString", responseXmlString);
        if ("REG".equalsIgnoreCase(serviceName)) {
            serviceName="";
            if (Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(responseXmlString))) == 0) {

                AppUtil.saveMpinNumber(mpinNumber, preferences, this);
                AppUtil.savePinNumberStatus(true, preferences);
                Intent i = new Intent(PinConfig.this, Login.class);
                startActivity(i);
                finish();
            }
        } else if ("OTP".equalsIgnoreCase(serviceName)) {
            serviceName="";
            if (Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(responseXmlString))) == 0) {

               registerMobileNumber();
            }
            else{
                AlertDialogueUtil.showAlertDialogue(this, getResources().getString(R.string.invalidOTP));
            }
        }

        else if ("RESEND_OTP".equalsIgnoreCase(serviceName)) {

            serviceName="";
            if (Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(responseXmlString))) == 0) {
                Toast.makeText(PinConfig.this, getString(R.string.OTPSent), Toast.LENGTH_SHORT).show();

            }

        }


    }

        private void registerMobileNumber ()
        {

            serviceName = "REG";
//		String input = "<Parameter><ProcessID>1001</ProcessID><MobileNo>" + mobileNumber + "</MobileNo><Parameter>";

            String input = "<Parameter><ProcessID>3004</ProcessID><MobileNo>" + mobileNo + "</MobileNo><IMEINo>" + imeiDeviceId + "</IMEINo></Parameter>";
            Log.e("process id 3001", input);
            AsyncCallWS asyncCallWS = new AsyncCallWS(PinConfig.this, input, PinConfig.this);
            asyncCallWS.execute();
        }

        private void validateOTP ()
        {
            serviceName = "OTP";

//		String input = "<Parameter><ProcessID>1001</ProcessID><MobileNo>" + mobileNumber + "</MobileNo><Parameter>";

            String input = "<Parameter><ProcessID>3003</ProcessID><MobileNo>" + mobileNo + "</MobileNo><OTP>" + otp.getText().toString() + "</OTP></Parameter>";
            Log.e("process id 3001", input);
            AsyncCallWS asyncCallWS = new AsyncCallWS(PinConfig.this, input, PinConfig.this);
            asyncCallWS.execute();
        }


    private void resendOTP ()
    {
        serviceName = "RESEND_OTP";

//		String input = "<Parameter><ProcessID>1001</ProcessID><MobileNo>" + mobileNumber + "</MobileNo><Parameter>";

        String input = "<Parameter><ProcessID>3002</ProcessID><MobileNo>" + mobileNo + "</MobileNo><ResendOTP>Y</ResendOTP></Parameter>";
        Log.e("process id 3001", input);
        AsyncCallWS asyncCallWS = new AsyncCallWS(PinConfig.this, input, PinConfig.this);
        asyncCallWS.execute();
    }




}
