package com.zenith.depositcollection.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class ConnectionMonitor extends BroadcastReceiver {

	public static boolean isConnectingToInternet(Context context)
	{
		ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivity != null)
		{
			NetworkInfo[] info = connectivity.getAllNetworkInfo();
			if (info != null)
				for (int i = 0; i < info.length; i++)
					if (info[i].getState() == NetworkInfo.State.CONNECTED)
					{
						return true;
					}

		}
		return false;
	}
	

	@Override
	public void onReceive(Context context, Intent arg1) {
		boolean intenetConnection = isConnectingToInternet(context);
		if (intenetConnection) 
		{
			//call the soap service
		} 
		else 
		{
			//
		}
	}
}
