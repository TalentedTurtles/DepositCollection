package com.zenith.depositcollection.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.zenith.depositcollection.R;
import com.zenith.depositcollection.db.CollectionDAO;
import com.zenith.depositcollection.db.Loan;


import java.util.ArrayList;
import java.util.List;

public class LoanDashboardListAdapter extends BaseAdapter implements Filterable {


    private final Activity context;
    private ArrayList<Loan> pigmyList = new ArrayList<>();
    private  ArrayList<Loan> filterPigmyList = new ArrayList<>();

    private LoanDashboardListAdapter.ItemFilter mFilter = new LoanDashboardListAdapter.ItemFilter();
    public LoanDashboardListAdapter(Activity context, ArrayList<Loan> pigmyCollList) {

        this.context = context;
        this.pigmyList = pigmyCollList;
        this.filterPigmyList=pigmyCollList;

    }
    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return filterPigmyList.size();
    }


    @Override
    public Object getItem(int position) {
        return filterPigmyList.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }


    public Filter getFilter() {
        return mFilter;
    }


    public View getView(int position, View convertView, ViewGroup parent) {
        LoanDashboardListAdapter.ViewHolder holder;
        if (convertView == null) {
            LayoutInflater inflater = context.getLayoutInflater();
            convertView = inflater.inflate(R.layout.dashboard_list_layout, null, true);
            holder = new LoanDashboardListAdapter.ViewHolder();
            holder.custIdView = (TextView) convertView.findViewById(R.id.custId);
            holder.custNameView = (TextView) convertView.findViewById(R.id.custName);
            holder.custBal = (TextView) convertView.findViewById(R.id.custBal1);
            holder.syncStatusImag = (ImageView) convertView.findViewById(R.id.statusIcon);
            convertView.setTag(holder);

        }else {
            // Get the ViewHolder back to get fast access to the TextView
            // and the ImageView.
            holder = (LoanDashboardListAdapter.ViewHolder) convertView.getTag();
        }


        Loan p = filterPigmyList.get(position);
        boolean syncStatus =  CollectionDAO.getSyncStatus(p.getAccountNo(),"asc");

        if (syncStatus) {
            holder.syncStatusImag.setImageResource(R.drawable.sync);
        }
        else{
            holder.syncStatusImag.setImageResource(R.drawable.unsync);
        }

        holder.custIdView.setText(Integer.toString(p.getAccountNo()));
        holder.custNameView.setText(p.getCustName());
        holder.custBal.setText(Double.toString(p.getBal()));
        return convertView;

    };
    static class ViewHolder {
        TextView custIdView;
        TextView custNameView;
        TextView custBal;
        ImageView syncStatusImag;

    }

    private class ItemFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {

            String filterString = constraint.toString().toLowerCase();

            FilterResults results = new FilterResults();

            final List<Loan> list = pigmyList;

            int count = list.size();
            final ArrayList<Loan> nlist = new ArrayList<Loan>(count);

            Loan filterableObj;

            for (int i = 0; i < count; i++) {
                filterableObj = list.get(i);
                if (filterableObj.getCustName().toLowerCase().contains(filterString)) {
                    nlist.add(filterableObj);
                }
                if (filterableObj.getAccountNo().toString().contains(filterString)) {
                    nlist.add(filterableObj);
                }
            }

            results.values = nlist;
            results.count = nlist.size();

            return results;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            filterPigmyList = (ArrayList<Loan>) results.values;
            notifyDataSetChanged();
        }

    }



}
