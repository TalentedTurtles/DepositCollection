package com.zenith.depositcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;

import com.zenith.depositcollection.db.DBHelper;
import com.zenith.depositcollection.util.AppUtil;

import java.util.ArrayList;
import java.util.List;

public class SplashActivity extends AppCompatActivity {

    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Hiding the action bar for splash screen
        //getActionBar().hide();
        preferences = PreferenceManager.getDefaultSharedPreferences(this);


        List<String> createQueryList = new ArrayList<String>();
        String pigmy_create = getString(R.string.PIGMY_CREATE);
        String loan_create = getString(R.string.LOAN_CREATE);
        String rd_create = getString(R.string.RD_CREATE);
        String coll_create = getString(R.string.COLLECTION);

        createQueryList.add(pigmy_create);
        createQueryList.add(coll_create);

        createQueryList.add(loan_create);
        createQueryList.add(rd_create);

        DBHelper.intializeDBInstance(this, createQueryList);

        new Handler().postDelayed(new Runnable() {


            @Override
            public void run() {
                if(AppUtil.getPinNumberStatus(preferences))
                {
                    Intent i = new Intent(SplashActivity.this, Login.class);
                    startActivity(i);
                    finish();
                }
                else {

                    String deviceIdentifir  = android.provider.Settings.Secure.getString(
                        SplashActivity.this.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);

                     AppUtil.saveDeviceIdentity(deviceIdentifir,preferences,SplashActivity.this);
                    // This method will be executed once the timer is over
                    Intent i = new Intent(SplashActivity.this, Registration.class);
                    startActivity(i);
                    finish();
                }
            }
        }, 2000);
}





}
