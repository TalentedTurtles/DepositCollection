package com.zenith.depositcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class BTPrint extends AppCompatActivity {

    Spinner selectPrinter;

    List<String> printers = new ArrayList<String>();
    private ArrayAdapter selectPrinterAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_btprint);

        selectPrinter = (Spinner) findViewById(R.id.selectPrinterType);
        printers.add("NGX BTP-110");
        printers.add("NGX BTP-120");
        printers.add("NGX NIX");
        printers.add("EPSON TM P-Series");


        selectPrinterAdapter = new ArrayAdapter(BTPrint.this, android.R.layout.simple_spinner_item, printers);
        selectPrinterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        selectPrinter.setAdapter(selectPrinterAdapter);
        selectPrinter.setSelection(0);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.home_menu,menu);

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId())
        {
            case android.R.id.home:
                // app icon in action bar clicked; go home
                onBackPressed();
                return true;

            case R.id.action_home_nav_btn:
                // app icon in action bar clicked; go home
                goHome();
                return true;

            case R.id.action_logout_nav_btn:
                // app icon in action bar clicked; go home
                showLogoutDialog(getResources().getString(R.string.alert_logout));
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void goHome()
    {
        Intent intent = new Intent(BTPrint.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void showLogoutDialog(String message)
    {
        final Dialog dialog = new Dialog(this);


//		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_two_btn_alert_dialog);

        dialog.setTitle(getString(R.string.logout));

        TextView textView = (TextView) dialog.findViewById(R.id.customAlert_text);

        Button cancelBtn = (Button) dialog.findViewById(R.id.cancel_btn);

        Button okBtn = (Button) dialog.findViewById(R.id.ok_btn);

        textView.setText(message);

        cancelBtn.setText(getString(R.string.no));
        okBtn.setText(getString(R.string.yes));


        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                dialog.dismiss();

            }
        });

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                Intent intent = new Intent(BTPrint.this, Login.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });

        dialog.show();

    }



}
