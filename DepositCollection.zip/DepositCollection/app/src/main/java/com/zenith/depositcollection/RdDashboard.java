package com.zenith.depositcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RdDashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rd_dashboard);
    }
}
