package com.zenith.depositcollection.asyncTask;

public interface AsyncResponse
{
	void processAsyncResponse(Object output);
}
