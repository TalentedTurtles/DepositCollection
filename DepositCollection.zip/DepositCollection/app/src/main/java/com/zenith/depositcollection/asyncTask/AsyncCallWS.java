package com.zenith.depositcollection.asyncTask;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;


import com.zenith.depositcollection.Login;
import com.zenith.depositcollection.R;
import com.zenith.depositcollection.util.AlertDialogueUtil;
import com.zenith.depositcollection.util.AppUtil;
import com.zenith.depositcollection.util.CryptUtilsNew ;

import com.zenith.depositcollection.util.StringUtil;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class AsyncCallWS extends AsyncTask<String, Void, Void>
{


	
	String inputToservice = "";

	String responseXmlString = "";

	Context context;

	ProgressDialog pDialog;
	
	int position;
	
	AsyncResponse asyncResponse;

	boolean isServerConnectFailed = false;

	public AsyncCallWS(Context context, String input, AsyncResponse response )
	{
		this.context = context;
		this.inputToservice = input;
		asyncResponse = response;
	}
	
	@Override
	protected Void doInBackground(String... params) {
		
		//callService(inputToservice);
		callRestService(inputToservice);
		return null;
	}

	
	@Override
	protected void onPostExecute(Void result) 
	{
		 super.onPostExecute(result);
		// cancel the dialogue
		if (pDialog != null && pDialog.isShowing())
		{
			pDialog.cancel();
		}

		if (StringUtil.hasValue(responseXmlString))
		{
			int errorNo = Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(responseXmlString)));

			String errorMsg = AppUtil.getXpathValue("Result/Message", AppUtil.buildDocument(responseXmlString));

			Log.e("ServiceResponse :",errorNo+" : "+errorMsg);

			if (errorNo == 0)
			{
				asyncResponse.processAsyncResponse(responseXmlString);
				//displayView(position,responseXmlString);
				// if  error code is 0
				
				/*Intent intent = new Intent(context, activityToOpen);
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				intent.putExtra("responseXml", responseXmlString);
				intent.putExtra("mobileNumber", mobileNumber);
				context.startActivity(intent);*/
			}else
			{

				errorMsg = AppUtil.getXpathValue("Result/Message", AppUtil.buildDocument(responseXmlString));

				if (errorNo == 4004 || errorMsg.trim().equalsIgnoreCase("Session has been expired"))
				{
					final Dialog dialog = new Dialog(context);
					dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
					dialog.setContentView(R.layout.custom_alert_dialogue);
					dialog.setCancelable(false);

					Button okButton = (Button) dialog.findViewById(R.id.alert_ok_btn);
					TextView textView = (TextView) dialog.findViewById(R.id.alert_message);
					textView.setText(errorMsg);
					okButton.setOnClickListener(new View.OnClickListener()
					{

						@Override
						public void onClick(View v)
						{
							try
							{
								if (dialog != null && dialog.isShowing())
								{
									dialog.cancel();
								}

								Intent intent = new Intent(context.getApplicationContext(), Login.class);

								context.startActivity(intent);
							}
							catch (Exception e)
							{
								// TODO: handle exception
							}

						}
					});
					dialog.show();

				}
				else if(isServerConnectFailed)
				{
					isServerConnectFailed =false;
					AlertDialogueUtil.showAlertDialogue(context,"Server Connection Failed!");
				}
				else
				{
					AlertDialogueUtil.showAlertDialogue(context,errorMsg);
				}


			}

		}
		else if(isServerConnectFailed)
		{
			isServerConnectFailed =false;
			AlertDialogueUtil.showAlertDialogue(context,"Server Connection Failed");
		}else
		{
			AlertDialogueUtil.showAlertDialogue(context,"Unable to reach our servers, Please try after some time");
		}
		
	}

	/**
	 * showProcessDialogue : <<Description>> 
	 */
	public void showProcessDialogue()
	{
		if (context != null)
		{
			pDialog = new ProgressDialog(context,R.style.TransparentProgressDialog);
			pDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			pDialog.setCancelable(false);
			pDialog.setMessage(context.getString(R.string.process_dialogue_message));
			pDialog.show();
		}
	}
	
	@Override
	protected void onPreExecute() 
	{
		//show the dialogue
		showProcessDialogue();
	}

	@Override
	protected void onProgressUpdate(Void... values)
	{
	}




	public void callRestService( String input)
	{

		CryptUtilsNew cryptUtils = new CryptUtilsNew();
		String encryptKey  = context.getString(R.string.encrypt_key);
		String CompressData = "";

		try {

			String encData = encryptKey+cryptUtils.encrypt(input, encryptKey);

			CompressData = cryptUtils.compress(encData);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (Exception ike)
		{

		}



		try
		{
			HttpClient client = new DefaultHttpClient();
			HttpPost post = new HttpPost(context.getString(R.string.service_url));
			post.setHeader("Content-Type", "text/xml");

			String xmlReq = "<string>"+CompressData+"</string>";
			StringEntity strEntity = new StringEntity(xmlReq, HTTP.UTF_8);

			//strEntity.setContentEncoding(new BasicHeader("Content-type", "application/xml"));

			post.setEntity(strEntity);


			HttpResponse response = client.execute(post);

			int statusCode = response.getStatusLine().getStatusCode();
			response.getEntity().toString();
			InputStream is = response.getEntity().getContent();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));

			String line = null;
			StringBuilder sb = new StringBuilder();

			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

			br.close();
			String result = sb.toString();


			String resultString = AppUtil.getXpathValue("/string", AppUtil.buildDocument(result));


			String decompressedResult = cryptUtils.decompress(resultString);


			String decryptText = new CryptUtilsNew().decrypt(decompressedResult, encryptKey);
			responseXmlString = decryptText;
		}
		catch (Exception e)
		{

			// cancel the dialogue
			if (pDialog != null)
			{
				pDialog.cancel();
			}
			isServerConnectFailed = true;
			e.printStackTrace();
		}
	}
	
}