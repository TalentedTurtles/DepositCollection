package com.zenith.depositcollection.db;

public class Loan {


    Integer accountNo;
    String custName;
    Double bal;
    String lastCollDate;
    Double collectionAmt;
    Double unsyncBal;
    String syncStatus;
    String lastSyncDate;
    String subSysCode;

    Double odAmt;
    Double instAmt;
    String odDate;

    public  Loan()
    {
        super();
    }
    public Loan(Integer accountNo,
                 String custName, Double bal, String lastCollDate,
                 Double collectionAmt, Double unsyncBal, String syncStatus, String lastSyncDate,String sysCode,Double odAmt,Double instAmt,String odDate) {
        super();

        this.accountNo=accountNo;
        this.custName=custName;
        this.bal=bal;
        this.lastCollDate=lastCollDate;
        this.collectionAmt=collectionAmt;
        this.unsyncBal=unsyncBal;
        this.syncStatus=syncStatus;
        this.lastCollDate=lastCollDate;
        this.subSysCode=sysCode;
        this.odAmt=odAmt;
        this.instAmt=instAmt;
        this.odDate=odDate;

    }


    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    public Integer getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(Integer accountNo) {
        this.accountNo = accountNo;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public Double getBal() {
        return bal;
    }

    public void setBal(Double bal) {
        this.bal = bal;
    }

    public String getLastCollDate() {
        return lastCollDate;
    }

    public void setLastCollDate(String lastCollDate) {
        this.lastCollDate = lastCollDate;
    }

    public Double getCollectionAmt() {
        return collectionAmt;
    }

    public void setCollectionAmt(Double collectionAmt) {
        this.collectionAmt = collectionAmt;
    }

    public Double getUnsyncBal() {
        return unsyncBal;
    }

    public void setUnsyncBal(Double unsyncBal) {
        this.unsyncBal = unsyncBal;
    }

    public String getSyncStatus() {
        return syncStatus;
    }

    public void setSyncStatus(String syncStatus) {
        this.syncStatus = syncStatus;
    }

    public String getLastSyncDate() {
        return lastSyncDate;
    }

    public void setLastSyncDate(String lastSyncDate) {
        this.lastSyncDate = lastSyncDate;
    }

    public String getSubSysCode() {
        return subSysCode;
    }

    public void setSubSysCode(String subSysCode) {
        this.subSysCode = subSysCode;
    }

    public Double getOdAmt() {
        return odAmt;
    }

    public void setOdAmt(Double odAmt) {
        this.odAmt = odAmt;
    }

    public Double getInstAmt() {

        return instAmt;
    }

    public void setInstAmt(Double instAmt) {
        this.instAmt = instAmt;
    }

    public String getOdDate() {
        return odDate;
    }

    public void setOdDate(String odDate) {
        this.odDate = odDate;
    }
}
