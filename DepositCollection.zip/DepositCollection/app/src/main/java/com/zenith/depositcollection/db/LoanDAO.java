package com.zenith.depositcollection.db;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.zenith.depositcollection.util.StringUtil;

import java.util.ArrayList;
import java.util.List;

public class LoanDAO {


    public static final String LOAN_ACCOUNTTRANSACTION_TABLE = "loanCollection";


    public static long insertAccountTransaction(Loan accountTransaction)
    {
        final SQLiteDatabase db = DBHelper.open();
        ContentValues value = new ContentValues();
        value.put("account_no", accountTransaction.getAccountNo());
        value.put("name", accountTransaction.getCustName());
        value.put("bal", accountTransaction.getBal());
        value.put("last_collection_date", accountTransaction.getLastCollDate());

        value.put("collectionAmt", accountTransaction.getCollectionAmt());
        value.put("unSyncBal", accountTransaction.getUnsyncBal());
        value.put("syncStatus", accountTransaction.getSyncStatus());

        value.put("last_sync_time", accountTransaction.getLastSyncDate());
        value.put("sub_code", accountTransaction.getSubSysCode());

        long insertedRowId = db.insert(LOAN_ACCOUNTTRANSACTION_TABLE, null, value);
        db.close();// Closing database connection
        return insertedRowId;
    }


    public static List<Loan> getAllAccountTransactions()
    {

        List<Loan> accountTransactionsList = new ArrayList<Loan>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + LOAN_ACCOUNTTRANSACTION_TABLE;

        final SQLiteDatabase db = DBHelper.open();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst())
        {
            do
            {

                Loan accountTransaction = new Loan();
                accountTransaction.setAccountNo(cursor.getInt(cursor.getColumnIndex("account_no")));
                accountTransaction.setBal(cursor.getDouble(cursor.getColumnIndex("bal")));
                accountTransaction.setCustName(cursor.getString(cursor.getColumnIndex("name")));
                accountTransaction.setLastCollDate(cursor.getString(cursor.getColumnIndex("last_collection_date")));
                accountTransaction.setCollectionAmt(cursor.getDouble(cursor.getColumnIndex("collectionAmt")));
                accountTransaction.setUnsyncBal(cursor.getDouble(cursor.getColumnIndex("unSyncBal")));
                accountTransaction.setSyncStatus(cursor.getString(cursor.getColumnIndex("syncStatus")));
                accountTransaction.setLastSyncDate(cursor.getString(cursor.getColumnIndex("last_sync_time")));
                accountTransaction.setSubSysCode(cursor.getString(cursor.getColumnIndex("sub_code")));

                accountTransactionsList.add(accountTransaction);
            }
            while (cursor.moveToNext());
        }

        // return AccountTransactions list
        return accountTransactionsList;
    }

    public static List<Loan> getAllAccountTransactionsByAccountNo(Integer accountNo, String sortOrder)
    {

        List<Loan> accountTransactionsList = new ArrayList<Loan>();
        // Select All Query
        if (!StringUtil.hasValue(sortOrder))
        {
            sortOrder = " asc ";
        }
        String selectQuery = "SELECT  * FROM " + LOAN_ACCOUNTTRANSACTION_TABLE + " WHERE " + "account_no="+"'"+accountNo+"'" ;
        final SQLiteDatabase db = DBHelper.open();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst())
        {
            do
            {

                Loan accountTransaction = new Loan();
                accountTransaction.setAccountNo(cursor.getInt(cursor.getColumnIndex("account_no")));
                accountTransaction.setBal(cursor.getDouble(cursor.getColumnIndex("bal")));
                accountTransaction.setCustName(cursor.getString(cursor.getColumnIndex("name")));
                accountTransaction.setLastCollDate(cursor.getString(cursor.getColumnIndex("last_collection_date")));
                accountTransaction.setCollectionAmt(cursor.getDouble(cursor.getColumnIndex("collectionAmt")));
                accountTransaction.setUnsyncBal(cursor.getDouble(cursor.getColumnIndex("unSyncBal")));
                accountTransaction.setSyncStatus(cursor.getString(cursor.getColumnIndex("syncStatus")));
                accountTransaction.setLastSyncDate(cursor.getString(cursor.getColumnIndex("last_sync_time")));
                accountTransaction.setSubSysCode(cursor.getString(cursor.getColumnIndex("sub_code")));

                accountTransactionsList.add(accountTransaction);
            }
            while (cursor.moveToNext());
        }

        // return AccountTransactions list
        return accountTransactionsList;
    }

    public static long updateLoanTransaction(Loan accountTransaction)
    {
        final SQLiteDatabase db = DBHelper.open();
        ContentValues value = new ContentValues();

        value.put("bal", accountTransaction.getBal());
        value.put("collectionAmt", accountTransaction.getCollectionAmt());
        value.put("last_collection_date", accountTransaction.getLastCollDate());
        //value.put("unSyncBal", accountTransaction.getUnsyncBal());
        value.put("syncStatus", accountTransaction.getSyncStatus());
        String updateQuery = "SELECT  * FROM " + LOAN_ACCOUNTTRANSACTION_TABLE;
        long updatedRowId = db.update(LOAN_ACCOUNTTRANSACTION_TABLE,value, "account_no="+"'"+accountTransaction.getAccountNo()+"'", null);
        db.close();// Closing database connection
        return updatedRowId;
    }

    public static void clearTransactions()
    {
        String deleteQuery = "delete from "+LOAN_ACCOUNTTRANSACTION_TABLE;

        final SQLiteDatabase db = DBHelper.open();

        db.delete(LOAN_ACCOUNTTRANSACTION_TABLE,null,null);
    }

}
