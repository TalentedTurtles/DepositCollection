/********************************************************************************
 * AppConstants.java   Apr 7, 2015
 *
 * Copyright (c) 2008 ZenithSoft.
 * The information contained in this document is the exclusive property of
 * Zenithsoft.  This work is protected under copyright laws of given countries of
 * origin and international laws, treaties and/or conventions.
 * No part of this document may be reproduced or transmitted in any form or by any means,
 * electronic or mechanical including photocopying or by any informational storage or
 * retrieval system, unless as expressly permitted by ZenithSoft.
 * 
 * Modification History :
 * Name				Date					Description
 * ----				----					-----------
 * mithunr			Apr 7, 2015					Created
 *******************************************************************************/
package com.zenith.depositcollection.util;

public interface AppConstants
{
	String REGISTER_FLAG = "registerFlag";

	String PIN_NUMBER = "pinNumber";
	
	String MOBILE_NUMBER = "mobileNumber";

	String CUSTOMER_ID = "customerID";


	String PRE_RECEIPT_NO = "receiptNO";

	String AGENT_COLLECTION_AMT_UNSYNC = "agentCollAmtUnSync";
	String AGENT_COLLECTION_AMT = "agentCollAmt";

	String FROM_LOGIN="fromLogin";

	String MPIN = "mpin";
	String DEICE_ID = "deiceId";
	String TOKEN = "token";

	String SESSION_ID = "sessionID";

	String CUSTOMER_NAME = "customerName";
	
	String LANGUAGE_CODE = "languageCode";

	String LOGIN_USER_INFO = "loginUserInfo";

	String PROFILE_IMAGE = "profileImage";
	/**
	 * Payee
	 */

	String SAME_BANK_BOOLEAN = "sameBankBoolean";

	String PAYEE_ACCOUNT_NO = "payeeAccountNo";

	String PAYEE_NAME = "payeeName";

	String PAYEE_NICK_NAME = "payeeNickName";

	String PAYEE_BANK_NAME = "payeeBankName";

	String PAYEE_IFSC = "payeeIfsc";

	String PAYEE_ACCOUNT_TYPE = "payeeAccountType";

	String PAYEE_ADDED_RESPONSE = "payeeAddedResponse";

	String ADDED_PAYEE_JSON = "addedPayeeJson";

	String FUND_TRANSFER_ENABLED_STATUS = "fundTransferEnabledStatus";

	String FUND_TRANSFER_DETAILS_JSON = "fundTransferDetailsJson";

	String OPEN_DEPOSIT_DETAILS_JSON = "openDepositDetailsJson";

	String LAST_LOGIN_TIME = "lastLoginTime";

	String CURRENT_LOGIN_TIME = "currentLoginTime";

	String USER_ACCOUNTS_XML_RESPONSE = "userAccountsXMLResponse";

	String OPEN_DEPOSIT_XML_RESPONSE = "openDepositXMLResponse";

	String USER_PASSBOOK_ACCOUNTS_XML_RESPONSE = "userPassbookAccountsXMLResponse";

	String FROM_ACTIVITY = "fromActivity";

	String GENERAL_INFO_ACTIVITY = "GENERAL_INFO_ACTIVITY";

	String OPEN_FD_RD_ACCOUNT = "OPEN_FD_RD_ACCOUNT";

	/*SMS Receiver*/

	public static final String SMS_SENDER_ID = "088689";

	/* Service URL*/

//	/*Local URL*/ String SERVICE_URL = "http://172.16.10.154:187/IBankingMWService.svc/Execute/XML";

//	/* SCDCC Bank Service URL */ String SERVICE_URL = "http://220.227.64.130:187/IBankingMWService.svc/Execute/XML";

//	/* SRI GOKARNANATH CO-OP BANK Service URL */ String SERVICE_URL = "http://220.227.64.130:290/IBankingMWService.svc/Execute/XML";

	/* DUCB Service URL */ String SERVICE_URL = "http://115.248.128.214:191/IBankingMWService.svc/Execute/XML";


	String AGENT_DETAILS="agentDetails";


}
