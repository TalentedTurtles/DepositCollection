package com.zenith.depositcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.zenith.depositcollection.asyncTask.AsyncCallWS;
import com.zenith.depositcollection.asyncTask.AsyncResponse;
import com.zenith.depositcollection.db.Loan;
import com.zenith.depositcollection.db.LoanDAO;
import com.zenith.depositcollection.db.Pigmy;
import com.zenith.depositcollection.db.PigmyDAO;
import com.zenith.depositcollection.db.RdDAO;
import com.zenith.depositcollection.db.RdData;
import com.zenith.depositcollection.util.AppUtil;
import com.zenith.depositcollection.util.StringUtil;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MasterSync extends AppCompatActivity implements AsyncResponse {
    SharedPreferences preferences;
    Button pigmyAcc;
    Button rd;
    Button loan;
    String selectedSchmeCode = "";
    Map<Integer,String> selectSchemeCodes=null;
    boolean isTokenService=false;
    String buttonType="";
    enum  bussinessType{
     PIGMY,LOAN,RD
    }
    enum  executionStatus{
        PIGMY,LOAN,RD
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_master_sync);
        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        pigmyAcc = (Button)findViewById(R.id.pigmyMaster) ;
        rd=(Button)findViewById(R.id.rdMaster);
        loan=(Button)findViewById(R.id.loanMaster);

        pigmyAcc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               // getAgentLinkPigmyAccounts();

                buttonType=bussinessType.PIGMY.toString();
                executeTokenService();


            }
        });


        rd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonType=bussinessType.RD.toString();

                executeTokenService();

            }
        });
        loan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonType=bussinessType.LOAN.toString();
                executeTokenService();
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.home_menu,menu);

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId())
        {
            case android.R.id.home:
                // app icon in action bar clicked; go home
                onBackPressed();
                return true;

            case R.id.action_home_nav_btn:
                // app icon in action bar clicked; go home
                goHome();
                return true;

            case R.id.action_logout_nav_btn:
                // app icon in action bar clicked; go home
                showLogoutDialog(getResources().getString(R.string.alert_logout));
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void goHome()
    {
        Intent intent = new Intent(MasterSync.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void showLogoutDialog(String message)
    {
        final Dialog dialog = new Dialog(this);


//		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_two_btn_alert_dialog);

        dialog.setTitle(getString(R.string.logout));

        TextView textView = (TextView) dialog.findViewById(R.id.customAlert_text);

        Button cancelBtn = (Button) dialog.findViewById(R.id.cancel_btn);

        Button okBtn = (Button) dialog.findViewById(R.id.ok_btn);

        textView.setText(message);

        cancelBtn.setText(getString(R.string.no));
        okBtn.setText(getString(R.string.yes));


        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                dialog.dismiss();

            }
        });

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                Intent intent = new Intent(MasterSync.this, Login.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });

        dialog.show();

    }
    private void getAgentLinkPigmyAccounts(String token)
    {
        String agentDetailsXml = AppUtil.getAgentDetails(preferences, this);
        if (Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(agentDetailsXml))) == 0)
        {
            String[] schemeTypes = AppUtil.getXpathValues("Result/Schemes/R/SubSysType", AppUtil.buildDocument(agentDetailsXml));
            String[] schemeCodes = AppUtil.getXpathValues("Result/Schemes/R/SubSysCode", AppUtil.buildDocument(agentDetailsXml));
            selectSchemeCodes = new HashMap<>();
            for (int  i = 0;  i < schemeTypes.length;  i++) {
                String schemeType = schemeTypes[i];
                if("PIGMY".equalsIgnoreCase(schemeType))
                {
                    String schemeCode = schemeCodes[i];

                    selectSchemeCodes.put(i,schemeCode);
                    executeAgentLinkAccService(schemeCode,token);
                }


            }

        }
    }

    private void getAgentLinkLoanAccounts(String token)
    {
        String agentDetailsXml = AppUtil.getAgentDetails(preferences, this);
        if (Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(agentDetailsXml))) == 0)
        {
            String[] schemeTypes = AppUtil.getXpathValues("Result/Schemes/R/SubSysType", AppUtil.buildDocument(agentDetailsXml));
            String[] schemeCodes = AppUtil.getXpathValues("Result/Schemes/R/SubSysCode", AppUtil.buildDocument(agentDetailsXml));

            for (int  i = 0;  i < schemeTypes.length;  i++) {
                String schemeType = schemeTypes[i];
                if("LOANS".equalsIgnoreCase(schemeType))
                {
                    String schemeCode = schemeCodes[i];
                    selectSchemeCodes = new HashMap<>();
                    selectSchemeCodes.put(i,schemeCode);
                    executeAgentLinkAccService(schemeCode,token);
                }


            }

        }
    }

    private void getAgentLinkRDAccounts(String token)
    {
        String agentDetailsXml = AppUtil.getAgentDetails(preferences, this);
        if (Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(agentDetailsXml))) == 0)
        {
            String[] schemeTypes = AppUtil.getXpathValues("Result/Schemes/R/SubSysType", AppUtil.buildDocument(agentDetailsXml));
            String[] schemeCodes = AppUtil.getXpathValues("Result/Schemes/R/SubSysCode", AppUtil.buildDocument(agentDetailsXml));

            for (int  i = 0;  i < schemeTypes.length;  i++) {
                String schemeType = schemeTypes[i];
                if("RD".equalsIgnoreCase(schemeType))
                {
                    String schemeCode = schemeCodes[i];
                    selectSchemeCodes = new HashMap<>();
                    selectSchemeCodes.put(i,schemeCode);
                    executeAgentLinkAccService(schemeCode,token);
                }


            }

        }
    }


    @Override
    public void processAsyncResponse(Object output) {
        String responseXmlString = (String) output;

        Log.e("responseXmlString", responseXmlString);
        if (Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(responseXmlString))) == 0) {

            if (isTokenService) {
                isTokenService = false;
                String tokenId = AppUtil.getXpathValue("Result/TokenID", AppUtil.buildDocument(responseXmlString));
                if (bussinessType.PIGMY.toString().equalsIgnoreCase(buttonType)) {
                    getAgentLinkPigmyAccounts(tokenId);
                }
                else  if (bussinessType.LOAN.toString().equalsIgnoreCase(buttonType)) {
                    getAgentLinkLoanAccounts(tokenId);

                }

                else  if (bussinessType.RD.toString().equalsIgnoreCase(buttonType)) {
                    getAgentLinkLoanAccounts(tokenId);

                }

            } else {

                if (bussinessType.PIGMY.toString().equalsIgnoreCase(buttonType)) {

                    String[] accounts = AppUtil.getXpathValues("Result/Schemes/R/AcNo", AppUtil.buildDocument(responseXmlString));
                    String[] accBal = AppUtil.getXpathValues("Result/Schemes/R/AcBal", AppUtil.buildDocument(responseXmlString));

                    String[] accName = AppUtil.getXpathValues("Result/Schemes/R/AcName", AppUtil.buildDocument(responseXmlString));

                    String[] LColDate = AppUtil.getXpathValues("Result/Schemes/R/LColDate", AppUtil.buildDocument(responseXmlString));

                    for (int i = 0; i < accounts.length; i++) {

                        Date today = new Date();
                        String dateStr = StringUtil.DateToStringFrmt(today);
                        Pigmy p = new Pigmy(Integer.parseInt(accounts[i]), accName[i], Double.parseDouble(accBal[i]), dateStr, 0.0, 0.0, "Y", dateStr, selectedSchmeCode);
                        PigmyDAO.insertAccountTransaction(p);

                    }
                    selectedSchmeCode = "";
                    Toast.makeText(MasterSync.this, getString(R.string.acc_Sync), Toast.LENGTH_SHORT).show();


                }
                else  if (bussinessType.LOAN.toString().equalsIgnoreCase(buttonType)) {
                    String[] accounts = AppUtil.getXpathValues("Result/Schemes/R/AcNo", AppUtil.buildDocument(responseXmlString));
                    String[] accBal = AppUtil.getXpathValues("Result/Schemes/R/AcBal", AppUtil.buildDocument(responseXmlString));

                    String[] accName = AppUtil.getXpathValues("Result/Schemes/R/AcName", AppUtil.buildDocument(responseXmlString));

                    String[] odAmt = AppUtil.getXpathValues("Result/Schemes/R/ODAmt", AppUtil.buildDocument(responseXmlString));

                    String[] instAmt = AppUtil.getXpathValues("Result/Schemes/R/InstAmt", AppUtil.buildDocument(responseXmlString));

                    String[] oDDate = AppUtil.getXpathValues("Result/Schemes/R/ODDate", AppUtil.buildDocument(responseXmlString));


                    String[] subSysCode = AppUtil.getXpathValues("Result/Schemes/R/SubSysCode", AppUtil.buildDocument(responseXmlString));

                    String[] LColDate = AppUtil.getXpathValues("Result/Schemes/R/LColDate", AppUtil.buildDocument(responseXmlString));



                    for (int i = 0; i < accounts.length; i++) {

                        Date today = new Date();
                        String dateStr = StringUtil.DateToStringFrmt(today);
                        Loan l = new Loan(Integer.parseInt(accounts[i]), accName[i], Double.parseDouble(accBal[i]), dateStr, 0.0, 0.0, "Y", dateStr, subSysCode[i],Double.parseDouble(odAmt[i]), Double.parseDouble(instAmt[i]),oDDate[i]);
                        LoanDAO.insertAccountTransaction(l);

                    }
                    selectedSchmeCode = "";
                    Toast.makeText(MasterSync.this, getString(R.string.acc_Sync), Toast.LENGTH_SHORT).show();

                }

                else  if (bussinessType.RD.toString().equalsIgnoreCase(buttonType)) {


                    String[] accounts = AppUtil.getXpathValues("Result/Schemes/R/AcNo", AppUtil.buildDocument(responseXmlString));
                    String[] accBal = AppUtil.getXpathValues("Result/Schemes/R/AcBal", AppUtil.buildDocument(responseXmlString));

                    String[] accName = AppUtil.getXpathValues("Result/Schemes/R/AcName", AppUtil.buildDocument(responseXmlString));

                    String[] LColDate = AppUtil.getXpathValues("Result/Schemes/R/LColDate", AppUtil.buildDocument(responseXmlString));

                    for (int i = 0; i < accounts.length; i++) {

                        Date today = new Date();
                        String dateStr = StringUtil.DateToStringFrmt(today);
                        RdData r = new RdData(Integer.parseInt(accounts[i]), accName[i], Double.parseDouble(accBal[i]), dateStr, 0.0, 0.0, "Y", dateStr, selectedSchmeCode);
                        RdDAO.insertAccountTransaction(r);

                    }
                    selectedSchmeCode = "";
                    Toast.makeText(MasterSync.this, getString(R.string.acc_Sync), Toast.LENGTH_SHORT).show();


                }
            }

        }
    }



    private void executeAgentLinkAccService(String schemeCode,String token)
    {
        selectedSchmeCode = schemeCode;

        String mobileNo = AppUtil.getMobileNumber(preferences,this);
        String imeiDeviceId = AppUtil.getDeviceIdentity(preferences,this);
        String tokenId=token;
        String agentId=AppUtil.getCustomerID(preferences,this);
        String input = "<Parameter><ProcessID>3102</ProcessID><MobileNo>"+mobileNo+"</MobileNo><IMEINo>"+imeiDeviceId+"</IMEINo><TokenID>"+tokenId+"</TokenID><AgentID>"+agentId+"</AgentID><SubSysCode>"+schemeCode+"</SubSysCode></Parameter>";
        Log.e("process id 3101",input);
        AsyncCallWS asyncCallWS = new AsyncCallWS(MasterSync.this, input,MasterSync.this);
        asyncCallWS.execute();
    }


    private void executeTokenService()
    {
        isTokenService=true;
        String mobileNo = AppUtil.getMobileNumber(preferences,this);
        String imeiDeviceId = AppUtil.getDeviceIdentity(preferences,this);
        String input = "<Parameter><ProcessID>3005</ProcessID><MobileNo>"+mobileNo+"</MobileNo><IMEINo>"+imeiDeviceId+"</IMEINo></Parameter>";
        Log.e("process id 3005",input);
        AsyncCallWS asyncCallWS = new AsyncCallWS(MasterSync.this, input,MasterSync.this);
        asyncCallWS.execute();
    }

}
