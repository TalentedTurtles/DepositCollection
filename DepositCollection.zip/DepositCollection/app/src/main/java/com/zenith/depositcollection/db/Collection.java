package com.zenith.depositcollection.db;

public class Collection {
    Integer accountNo;
    Double collectionAmt;
    String lastCollDate;
    String syncStatus;
    String subSysCode;
    Integer receiptNo;

    public Integer getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(Integer accountNo) {
        this.accountNo = accountNo;
    }

    public Double getCollectionAmt() {
        return collectionAmt;
    }

    public void setCollectionAmt(Double collectionAmt) {
        this.collectionAmt = collectionAmt;
    }

    public String getLastCollDate() {
        return lastCollDate;
    }

    public void setLastCollDate(String lastCollDate) {
        this.lastCollDate = lastCollDate;
    }

    public String getSyncStatus() {
        return syncStatus;
    }

    public void setSyncStatus(String syncStatus) {
        this.syncStatus = syncStatus;
    }

    public String getSubSysCode() {
        return subSysCode;
    }

    public void setSubSysCode(String subSysCode) {
        this.subSysCode = subSysCode;
    }

    public Integer getReceiptNo() {
        return receiptNo;
    }

    public void setReceiptNo(Integer receiptNo) {
        this.receiptNo = receiptNo;
    }
}
