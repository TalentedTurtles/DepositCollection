package com.zenith.depositcollection.util;


import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.zenith.depositcollection.R;
import com.zenith.depositcollection.R.string;
import com.zenith.depositcollection.SplashActivity;


public class AlertDialogueUtil 
{
	public  static Dialog showAlertDialogue(Context context, String message)
	{
		final Dialog dialog = new Dialog(context);
//		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.custom_alert_dialogue);
		dialog.setCancelable(false);
		dialog.setTitle("Alert");
		
		/*//to make the back ground blur(dim) on displaying alert dialogue
		WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();  
		lp.dimAmount=0.5f;  
		dialog.getWindow().setAttributes(lp);  
		dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);  
		*/
		Button okButton = (Button) dialog.findViewById(R.id.alert_ok_btn);
		TextView textView = (TextView) dialog.findViewById(R.id.alert_message);
		textView.setText(message);
		okButton.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View v)
			{
				try
				{
					dialog.dismiss();
				}
				catch (Exception e)
				{
					// TODO: handle exception
				}
				
			}
		});
		dialog.show();
		return dialog;
	}

	public static void showOkAlertDialog(Context context,String message)
	{

		Display display = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		int mwidth = display.getWidth();
		int mheight = display.getHeight();

		final Dialog dialog = new Dialog(context);

		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.custom_alert_dialogue);

		WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();
		lp.dimAmount=0.8f;
		lp.width = mwidth;
//        lp.height = mheight;
		lp.x = (mwidth)*4/5;
//        lp.height = (mheight)*4/5;

		dialog.getWindow().setAttributes(lp);

		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

//        dialog.setTitle("Alert");

		TextView textView = (TextView) dialog.findViewById(R.id.alert_message);

		textView.setText(message);


		Button okBtn = (Button) dialog.findViewById(R.id.alert_ok_btn);

		textView.setText(message);

		okBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				dialog.dismiss();

			}
		});

		dialog.show();
	}
	
	@SuppressLint("NewApi")
	public static Dialog createDialog(final Context context, String message)
	{
		final Dialog dialog = new Dialog(context);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.custom_alert_dialogue_two_btn);

		// to make the back ground blur(dim) on displaying alert dialogue
		/*WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();
		lp.dimAmount = 0.8f;
		dialog.getWindow().setAttributes(lp);
		dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);*/
		Button saveBtn = (Button) dialog.findViewById(R.id.delete_cancel_btn);
		saveBtn.setText(context.getString(R.string.exit));
		//saveBtn.setBackground(context.getResources().getDrawable(R.drawable.exit));
		Button cancelBtn = (Button) dialog.findViewById(R.id.delete_ok_btn);
		cancelBtn.setText(context.getString(R.string.cancel));
		//cancelBtn.setBackground(context.getResources().getDrawable(R.drawable.cancel_small));
		TextView textView = (TextView) dialog.findViewById(R.id.delete_confirm_message);
		textView.setText(message);
		saveBtn.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View v)
			{
				try
				{
					//on click change the back ground color
					//v.setBackgroundColor(context.getResources().getColor(R.color.buttonOverlayBlackColor));
					// go to home activity
					Intent exitActivity = new Intent(context, SplashActivity.class);
					exitActivity.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
					exitActivity.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					exitActivity.putExtra("EXIT", true);
					context.startActivity(exitActivity);
				}
				catch (Exception e)
				{
					// TODO: handle exception
				}

			}
		});
		cancelBtn.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View v)
			{
				try
				{
					//on click change the back ground color
					//v.setBackgroundColor(context.getResources().getColor(R.color.buttonOverlayBlackColor));
					dialog.dismiss();
				}
				catch (Exception e)
				{
					// TODO: handle exception
				}

			}
		});
		dialog.show();
		return dialog;
	}
	

}
