package com.zenith.depositcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.zenith.depositcollection.asyncTask.AsyncCallWS;
import com.zenith.depositcollection.asyncTask.AsyncResponse;
import com.zenith.depositcollection.db.DBHelper;
import com.zenith.depositcollection.util.AppConstants;
import com.zenith.depositcollection.util.AppUtil;
import com.zenith.depositcollection.util.StringUtil;

import java.util.ArrayList;
import java.util.List;

public class Login extends AppCompatActivity implements AsyncResponse {

    Button signIn;
    EditText mpinLogin;
    SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        signIn = (Button)findViewById(R.id.signInBtn);
        mpinLogin = (EditText)findViewById(R.id.mpinEditTxt);
        preferences = PreferenceManager.getDefaultSharedPreferences(this);


        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!StringUtil.hasValue(mpinLogin.getText().toString()))
                {
                    mpinLogin.setError(getString(R.string.field_err_msg));
                    return;
                }
                String mpinSaved = AppUtil.getMpinNumber(preferences,Login.this);

                if(!mpinLogin.getText().toString().equals(mpinSaved))
                {
                    mpinLogin.setError(getString(R.string.mpin_err_msg));
                    return;
                }


                executeTokenService();

            }
        });


    }
    @Override
    public void processAsyncResponse(Object output) {
        String responseXmlString = (String) output;
        Log.e("responseXmlString", responseXmlString);
        if (Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(responseXmlString))) == 0) {
           String tokenId =  AppUtil.getXpathValue("Result/TokenID", AppUtil.buildDocument(responseXmlString));
            AppUtil.saveToken(tokenId,preferences,this);

            Intent i = new Intent(Login.this,MainActivity.class);
            i.putExtra(AppConstants.FROM_LOGIN,true);
            startActivity(i);
            finish();
        }
    }


    private void executeTokenService()
    {

       String mobileNo = AppUtil.getMobileNumber(preferences,this);
       String imeiDeviceId = AppUtil.getDeviceIdentity(preferences,this);
        String input = "<Parameter><ProcessID>3005</ProcessID><MobileNo>"+mobileNo+"</MobileNo><IMEINo>"+imeiDeviceId+"</IMEINo></Parameter>";
        Log.e("process id 3005",input);
        AsyncCallWS asyncCallWS = new AsyncCallWS(Login.this, input,Login.this);
        asyncCallWS.execute();
    }

}
