package com.zenith.depositcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.zenith.depositcollection.adapter.DashboardListAdapter;
import com.zenith.depositcollection.db.Pigmy;
import com.zenith.depositcollection.db.PigmyDAO;
import com.zenith.depositcollection.util.AlertDialogueUtil;
import com.zenith.depositcollection.util.AppUtil;
import com.zenith.depositcollection.util.StringUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Dashboard extends AppCompatActivity {
    ListView list;
    SearchView searchView;
    DashboardListAdapter adapter;
     ArrayList<Pigmy> pigmyList;


    SharedPreferences preferences;

    public void setActionBar(Toolbar toolbar) {
        super.setActionBar(toolbar);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        preferences = PreferenceManager.getDefaultSharedPreferences(this);


        pigmyList = (ArrayList<Pigmy>) PigmyDAO.getAllAccountTransactions();
        if(pigmyList == null || pigmyList.isEmpty()) {
            AlertDialogueUtil.showAlertDialogue(this, getString(R.string.empty_acc_list));
        }
       /* if(pigmyList.size() < 1)
        {
            Pigmy p = new Pigmy(1001,"ANAND",340.0,"23/4/2001",0.0,200.0,"N","12/3/2001");
            Pigmy p1 = new Pigmy(1002,"SEKHAR",340.0,"23/4/2001",0.0,200.0,"Y","12/3/2001");
            Pigmy p2 = new Pigmy(1003,"LAXMI",340.0,"23/4/2001",0.0,200.0,"N","12/3/2001");
            Pigmy p3 = new Pigmy(1004,"KESAV",340.0,"19/10/2001",0.0,200.0,"N","12/3/2001");

            PigmyDAO.insertAccountTransaction(p);

            PigmyDAO.insertAccountTransaction(p1);
            PigmyDAO.insertAccountTransaction(p2);

            PigmyDAO.insertAccountTransaction(p3);
            pigmyList = (ArrayList<Pigmy>) PigmyDAO.getAllAccountTransactions();

        }*/
        //Update Agent bal
       /*Double totalCollBal =0.0;
        Double totalUnsyncBal=0.0;
        if(pigmyList != null && !pigmyList.isEmpty()) {
            for (Pigmy p : pigmyList) {
                String lastCollDate = p.getLastCollDate();
                 String today = StringUtil.DateToStringFrmt(new Date());
                if (lastCollDate.equalsIgnoreCase(today)) {
                    totalCollBal = totalCollBal + p.getCollectionAmt();
                    totalUnsyncBal = totalUnsyncBal + p.getUnsyncBal();
                }

            }
            AppUtil.saveAgentUnSyncCollBal(totalUnsyncBal.toString(), preferences, this);
            AppUtil.saveAgentCollBal(totalCollBal.toString(), preferences, this);
        }*/

        adapter=new DashboardListAdapter(this, pigmyList);
        list=(ListView)findViewById(R.id.dashboardList);
       // final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, android.R.id.text1,custName);

        list.setAdapter(adapter);
        searchView = (SearchView) findViewById(R.id.searchView);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {


                    adapter.getFilter().filter(query);

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                  adapter.getFilter().filter(newText);
                return false;
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // TODO Auto-generated method stub

               Pigmy p =  pigmyList.get(position);
                Intent intent = new Intent(Dashboard.this,PigmyCollect.class);
                intent.putExtra("account_no", p.getAccountNo());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);




            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent pigmyCollect = new Intent(Dashboard.this,MainActivity.class);
        startActivity(pigmyCollect);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.home_menu,menu);

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId())
        {
            case android.R.id.home:
                // app icon in action bar clicked; go home
                onBackPressed();
                return true;

            case R.id.action_home_nav_btn:
                // app icon in action bar clicked; go home
                goHome();
                return true;

            case R.id.action_logout_nav_btn:
                // app icon in action bar clicked; go home
                showLogoutDialog(getResources().getString(R.string.alert_logout));
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }




    private void goHome()
    {
        Intent intent = new Intent(Dashboard.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void showLogoutDialog(String message)
    {
        final Dialog dialog = new Dialog(this);


//		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_two_btn_alert_dialog);

        dialog.setTitle(getString(R.string.logout));

        TextView textView = (TextView) dialog.findViewById(R.id.customAlert_text);

        Button cancelBtn = (Button) dialog.findViewById(R.id.cancel_btn);

        Button okBtn = (Button) dialog.findViewById(R.id.ok_btn);

        textView.setText(message);

        cancelBtn.setText(getString(R.string.no));
        okBtn.setText(getString(R.string.yes));


        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                dialog.dismiss();

            }
        });

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                Intent intent = new Intent(Dashboard.this, Login.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });

        dialog.show();

    }





}
