package com.zenith.depositcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.zenith.depositcollection.asyncTask.AsyncCallWS;
import com.zenith.depositcollection.asyncTask.AsyncResponse;
import com.zenith.depositcollection.model.AccountTransaction;
import com.zenith.depositcollection.util.AlertDialogueUtil;
import com.zenith.depositcollection.util.AppUtil;
import com.zenith.depositcollection.util.ConnectionMonitor;
import com.zenith.depositcollection.util.StringUtil;

import java.util.ArrayList;
import java.util.List;

public class AgentStatement extends AppCompatActivity implements AsyncResponse {
    SharedPreferences preferences;
    String transactionDetailsXml;

    String[] trasnsactionTimes ;
    String[] particulars ;
    String[] insNumbers ;
    String[] insDates ;
    String[] debits ;
    String[] credits ;
    String[] balances ;
    String[] timestamps ;
    boolean isTokenService;
    List<AccountTransaction> accountTransactionList = new ArrayList<AccountTransaction>();

    private TableLayout tableLayout;

    private AccountTransaction selectedTransaction;

    private boolean sort_flag = false;

    TextView accountNumberTxt;
    TextView accountNameTxt;
    TextView openBalTxt;
    TextView closeBalTxt;




    //private TableLayout HeaderTablelayout;

    Button nxtButton;

    Button prevButton;

    int min = 0;

    int max = 0;
   String accountNo;
   String accountName;
   String openBal;
   String closeBal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_statement);
        preferences = PreferenceManager.getDefaultSharedPreferences(this);

        tableLayout = (TableLayout) findViewById(R.id.passBookTransactionsTable);
        nxtButton = (Button) findViewById(R.id.passBookNxtButton);
        prevButton = (Button) findViewById(R.id.passBookPrevButton);

        accountNumberTxt=(TextView)findViewById(R.id.agentAccNoVal);
        accountNameTxt=(TextView)findViewById(R.id.agentNameVal);
        openBalTxt=(TextView)findViewById(R.id.openBalVal);
        closeBalTxt=(TextView)findViewById(R.id.closeBalVal);
        nxtButtonClickListener();
        prevButtonClickListene();
        executeTokenService();
      //  getAgentStatementDetails();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent pigmyCollect = new Intent(AgentStatement.this,MainActivity.class);
        startActivity(pigmyCollect);
        finish();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.home_menu,menu);

        return true;
    }

    private void initializePassbook(String responseXml)
    {
        if (StringUtil.hasValue(responseXml))
        {
            transactionDetailsXml = responseXml;

            resetValues();
            accountNo = AppUtil.getXpathValue("Result/Details/AccountNo", AppUtil.buildDocument(transactionDetailsXml));
            accountName = AppUtil.getXpathValue("Result/Details/AccName", AppUtil.buildDocument(transactionDetailsXml));
            openBal = AppUtil.getXpathValue("Result/Balance/OpenBal", AppUtil.buildDocument(transactionDetailsXml));

            closeBal = AppUtil.getXpathValue("Result/Balance/CloseBal", AppUtil.buildDocument(transactionDetailsXml));

            accountNumberTxt.setText(accountNo);
            accountNameTxt.setText(accountName);
            openBalTxt.setText(openBal);
            closeBalTxt.setText(closeBal);

            trasnsactionTimes = AppUtil.getXpathValues("Result/Transaction/R/C2", AppUtil.buildDocument(transactionDetailsXml));
            particulars = AppUtil.getXpathValues("Result/Transaction/R/C5", AppUtil.buildDocument(transactionDetailsXml));
           // insNumbers = AppUtil.getXpathValues("Result/Transaction/Insnumber", AppUtil.buildDocument(transactionDetailsXml));
            //insDates = AppUtil.getXpathValues("Result/Transaction/Insdate", AppUtil.buildDocument(transactionDetailsXml));
            debits = AppUtil.getXpathValues("Result/Transaction/R/C6", AppUtil.buildDocument(transactionDetailsXml));
            credits = AppUtil.getXpathValues("Result/Transaction/R/C7", AppUtil.buildDocument(transactionDetailsXml));
            balances = AppUtil.getXpathValues("Result/Transaction/R/C8", AppUtil.buildDocument(transactionDetailsXml));
           // timestamps = AppUtil.getXpathValues("Result/Transaction/TimeStamp", AppUtil.buildDocument(transactionDetailsXml));

            for (int i = 0; i < trasnsactionTimes.length; i++)
            {
                accountTransactionList.add(new AccountTransaction(accountNo,trasnsactionTimes[i],particulars[i],debits[i],credits[i],balances[i]));
            }

          /* if ( accountTransactionList != null && !accountTransactionList.isEmpty())
            {

               // AccountTransactionDao.clearTransactions();

                for (AccountTransaction accountTransaction : accountTransactionList)
                {
                 //   AccountTransactionDao.insertAccountTransaction(accountTransaction);
                }

            }*/
            //get transaction data from db
           // accountTransactionList = AccountTransactionDao.getAllAccountTransactionsByAccountNo(accountNo," asc");
        }
      /*  else
        {
            accountTransactionList = AccountTransactionDao.getAllAccountTransactionsByAccountNo(accountNo," asc ");
        }*/

        refresh(0,0);
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId())
        {
            case android.R.id.home:
                // app icon in action bar clicked; go home
                onBackPressed();
                return true;

            case R.id.action_home_nav_btn:
                // app icon in action bar clicked; go home
                goHome();
                return true;

            case R.id.action_logout_nav_btn:
                // app icon in action bar clicked; go home
                showLogoutDialog(getResources().getString(R.string.alert_logout));
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void goHome()
    {
        Intent intent = new Intent(AgentStatement.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void showLogoutDialog(String message)
    {
        final Dialog dialog = new Dialog(this);


//		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_two_btn_alert_dialog);

        dialog.setTitle(getString(R.string.logout));

        TextView textView = (TextView) dialog.findViewById(R.id.customAlert_text);

        Button cancelBtn = (Button) dialog.findViewById(R.id.cancel_btn);

        Button okBtn = (Button) dialog.findViewById(R.id.ok_btn);

        textView.setText(message);

        cancelBtn.setText(getString(R.string.no));
        okBtn.setText(getString(R.string.yes));


        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                dialog.dismiss();

            }
        });

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                Intent intent = new Intent(AgentStatement.this, Login.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });

        dialog.show();

    }
    private void resetValues()
    {
        trasnsactionTimes  = null ;
        particulars   	   = null ;
        insNumbers   	   = null ;
        insDates   		   = null ;
        debits   		   = null ;
        credits   		   = null ;
        balances    	   = null ;
        timestamps   	   = null ;
    }

    private void refresh(int min_, int max_)
    {

        if (min_ == 0 && max_ == 0)
        {
            if ( accountTransactionList.size() > 10)
            {
                min = 0;
                max = 10;
            }
            else
            {
                min = 0;
                max = accountTransactionList.size();
            }
        }


        if (tableLayout != null)
        {
            tableLayout.removeAllViews();
        }
        addHeaderRowWithData(new String[] { getString(R.string.txnDate),getString(R.string.txnParticulars),getString(R.string.txnDebit),getString(R.string.txnCredit), getString(R.string.txnBal)} );
        for (int i = min; i < max; i++)
        {
            //addHeaderRowWithData(new String[] { getString(R.string.transaction_header) + Integer.toString(i + 1) }, fiveTransactionTableLayout);
            addRowWithData(new String[] { accountTransactionList.get(i).getTransactionDate(),accountTransactionList.get(i).getParticulars(), accountTransactionList.get(i).getDebit(), accountTransactionList.get(i).getCredit(),accountTransactionList.get(i).getBalance() } );
            //addRowWithData(new String[] { "Amount : ", t_amounts[i] }, fiveTransactionTableLayout);
            //addRowWithData(new String[] { "Particulars: ", t_particulars[i] }, fiveTransactionTableLayout);
            //addEmptyRow(new String[] { "", "" }, fiveTransactionTableLayout);
        }


    }

    @SuppressLint("NewApi")
    public void addRowWithData(String[] RowData)
    {

        /** Create a TableRow dynamically **/
        TableRow tr = new TableRow(this);
        TableLayout.LayoutParams tableRowParams = new TableLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
       // tableRowParams.setMargins(3, 3, 2, 10);
        tr.setLayoutParams(tableRowParams);

        for (int i = 0; i < RowData.length; i++)
        {
            TextView columnText = new TextView(this);
            if (i == RowData.length - 1)
            {
                //columnText.setVisibility(View.GONE);
            }
            if (i == RowData.length - 2)
            {
               // columnText.setVisibility(View.GONE);
            }
            if (i == 2 || i == 3 || i == 4)
            {
                columnText.setGravity(Gravity.RIGHT);
            }
            else
            {
            }
            columnText.setBackground(getResources().getDrawable(R.drawable.table_layout_border));

            if (i == 2 && StringUtil.hasValue(RowData[2]) && !RowData[i].equalsIgnoreCase("0"))
            {
                columnText.setTextColor((getResources().getColor(R.color.red)));
               // columnText.setGravity(Gravity.);
            }
            else if (i == 3 && StringUtil.hasValue(RowData[3]) && !RowData[i].equalsIgnoreCase("0"))
            {
                columnText.setTextColor(getResources().getColor(R.color.green));

            }


           // columnText.setMaxEms(7);
//			columnText.setSingleLine();
            if (StringUtil.hasValue(RowData[i]) && RowData[i].equalsIgnoreCase("0"))
            {
                columnText.setText("");
            }
            else
            {
                columnText.setText(RowData[i]);
            }



            columnText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            columnText.setMinHeight(30);
            columnText.setPadding(5, 5, 5, 5);
            columnText.setLayoutParams(new TableRow.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
            //columnText.setBackground(getResources().getDrawable(R.drawable.border));
            tr.addView(columnText); // Adding textView to tablerow.
        }

        //tr.setBackground(getResources().getDrawable(R.drawable.border_edit_text));
        //tr.setBackgroundColor(getResources().getColor(R.color.cream_));
        //tr.setClickable(true);
        // tr.setPadding(10, 10, 5, 5);
        tr.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View view)
            {
                TableRow tableRow = (TableRow) view;
                TextView textView = (TextView) tableRow.getChildAt(tableRow.getChildCount()-1);
                String transaction_id = textView.getText().toString();
                for (AccountTransaction accountTransaction : accountTransactionList)
                {
                    if (accountTransaction.getId() == Long.parseLong(transaction_id))
                    {
                        selectedTransaction = accountTransaction;
                        break;
                    }
                }
                //createTransactionEditDialog();
            }

        });

        // Add the TableRow to the TableLayout
        tableLayout.addView(tr, new TableLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
    }


    @SuppressLint("NewApi")
    public void addHeaderRowWithData(String[] RowData)
    {

        /** Create a TableRow dynamically **/
        TableRow tr = new TableRow(this);
        tr.setBackgroundColor(getResources().getColor(R.color.grey_light));
        TableLayout.LayoutParams tableRowParams = new TableLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tableRowParams.setMargins(3, 3, 2, 10);
        tr.setLayoutParams(tableRowParams);

        for (int i = 0; i < RowData.length; i++)
        {
            TextView columnText = new TextView(this);



			/*	if (i == 1)
			{
				columnText.setTextSize(13);
			}
			else
			{
				columnText.setTextSize(15);
			}*/
//			columnText.setMaxEms(10);
            columnText.setSingleLine();
            columnText.setText(RowData[i]);
            columnText.setBackground(getResources().getDrawable(R.drawable.border_text_view));
            columnText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            columnText.setMinHeight(30);

            columnText.setPadding(5, 5, 5, 5);
            columnText.setLayoutParams(new TableRow.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
            //columnText.setBackground(getResources().getDrawable(R.drawable.border));
            tr.addView(columnText); // Adding textView to tablerow.
        }

        //tr.setBackground(getResources().getDrawable(R.drawable.border_edit_text));
        //tr.setBackgroundColor(getResources().getColor(R.color.action_bar_red_light));
		/*tr.setClickable(true);
		// tr.setPadding(10, 10, 5, 5);
		tr.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View view)
			{
			}

		});*/

        // Add the TableRow to the TableLayout
        tableLayout.addView(tr, new TableLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
    }


    /**
     * prevButtonClickListene : <<Description>>
     */
    private void prevButtonClickListene()
    {
        prevButton.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View view)
            {
                if (min > 10)
                {
                    min = min - 10;
                }
                else
                {
                    min = min - min;
                }

                if (max % 10 == 0 && max > 10)
                {
                    max = max - 10;
                }
                else
                {
                    max = max - max % 10;
                }

                refresh(min, max);
            }
        });
    }

    /**
     * nxtButtonClickListener : <<Description>>
     */
    private void nxtButtonClickListener()
    {
        nxtButton.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View view)
            {
                if (max < accountTransactionList.size())
                {

                    min = max;
                    if (accountTransactionList.size() > max+10)
                    {
                        max = max + 10;
                    }
                    else
                    {
                        max = max + (accountTransactionList.size() - max);
                    }
                    refresh(min, max);
                }
                else
                {
                    Toast.makeText(AgentStatement.this, getString(R.string.err_no_data), Toast.LENGTH_LONG).show();
                }

            }
        });
    }





    private void getAgentStatementDetails(String token)
    {
        if (ConnectionMonitor.isConnectingToInternet(this))
        {
            String mobileNo = AppUtil.getMobileNumber(preferences,this);
            String imeiDeviceId = AppUtil.getDeviceIdentity(preferences,this);
            String tokenId= token;
            String agentId=AppUtil.getCustomerID(preferences,this);
            String input = "<Parameter><ProcessID>3103</ProcessID><MobileNo>"+mobileNo+"</MobileNo><IMEINo>"+imeiDeviceId+"</IMEINo><TokenID>"+tokenId+"</TokenID><AgentID>"+agentId+"</AgentID><StmtDate>15/07/2020</StmtDate></Parameter>";
            Log.e("process id 3103",input);
            AsyncCallWS asyncCallWS = new AsyncCallWS(AgentStatement.this, input,AgentStatement.this);
            asyncCallWS.execute();
        }
        else
        {
            AlertDialogueUtil.showAlertDialogue(this,getString(R.string.no_internet_body_text));
        }
    }

    @Override
    public void processAsyncResponse(Object output)
    {
        String responseXmlString = (String) output;
        if (Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(responseXmlString))) == 0) {
            if (isTokenService) {
                isTokenService=false;
                String tokenId =  AppUtil.getXpathValue("Result/TokenID", AppUtil.buildDocument(responseXmlString));
                getAgentStatementDetails(tokenId);

            }else
            {


                initializePassbook(responseXmlString);

            }


        }


    }


    private void executeTokenService()
    {
        isTokenService=true;
        String mobileNo = AppUtil.getMobileNumber(preferences,this);
        String imeiDeviceId = AppUtil.getDeviceIdentity(preferences,this);
        String input = "<Parameter><ProcessID>3005</ProcessID><MobileNo>"+mobileNo+"</MobileNo><IMEINo>"+imeiDeviceId+"</IMEINo></Parameter>";
        Log.e("process id 3005",input);
        AsyncCallWS asyncCallWS = new AsyncCallWS(AgentStatement.this, input,AgentStatement.this);
        asyncCallWS.execute();
    }



}
