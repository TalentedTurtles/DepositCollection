package com.zenith.depositcollection.model;

import com.zenith.depositcollection.util.AppUtil;

/**
 * Created by rsekhar on 27/06/17.
 */

public class User {

    private String name;
    private String email;
    private String mobileNo;
    private String branchCode;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String bankShortName;
    private String bankName;
    private String userInfo;

    public User(String userXMLData)
    {
        super();
        this.userInfo = userXMLData;

    }

    public String getName() {
        return AppUtil.getXpathValue("Result/CustName",AppUtil.buildDocument(userInfo));
    }

    public String getEmail() {
        return AppUtil.getXpathValue("Result/EMailID",AppUtil.buildDocument(userInfo));
    }

    public String getMobileNo() {
        return AppUtil.getXpathValue("Result/MobileNo",AppUtil.buildDocument(userInfo));
    }

    public String getBranchCode() {
        return AppUtil.getXpathValue("Result/BaseBranch",AppUtil.buildDocument(userInfo));
    }

    public String getAddress1() {
        return AppUtil.getXpathValue("Result/Add1",AppUtil.buildDocument(userInfo));
    }

    public String getAddress2() {
        return AppUtil.getXpathValue("Result/Add2",AppUtil.buildDocument(userInfo));
    }

    public String getAddress3() {
        return AppUtil.getXpathValue("Result/Add3",AppUtil.buildDocument(userInfo));
    }

    public String getAddress4() {
        return AppUtil.getXpathValue("Result/Add4",AppUtil.buildDocument(userInfo));
    }

    public String getBankShortName() {
        return AppUtil.getXpathValue("Result/BankShortName",AppUtil.buildDocument(userInfo));
    }

    public String getBankName() {
        return AppUtil.getXpathValue("Result/BankName",AppUtil.buildDocument(userInfo));
    }

    public String getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(String userInfo) {
        this.userInfo = userInfo;
    }
}
