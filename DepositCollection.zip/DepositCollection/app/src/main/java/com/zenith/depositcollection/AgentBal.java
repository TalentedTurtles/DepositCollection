package com.zenith.depositcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.zenith.depositcollection.asyncTask.AsyncCallWS;
import com.zenith.depositcollection.asyncTask.AsyncResponse;
import com.zenith.depositcollection.db.CollectionDAO;
import com.zenith.depositcollection.db.Pigmy;
import com.zenith.depositcollection.db.PigmyDAO;
import com.zenith.depositcollection.util.AppUtil;
import com.zenith.depositcollection.util.StringUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AgentBal extends AppCompatActivity implements AsyncResponse {

     SharedPreferences preferences;
     TextView agentId;
     TextView agentName;
     TextView agentAccNo;
     TextView collectionLmt;
     TextView accBal;
     TextView collectionTotal;
     TextView unsyncBal   ;
     boolean isTokenService = false;
     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_bal);
        preferences = PreferenceManager.getDefaultSharedPreferences(this);

         agentId = (TextView) findViewById(R.id.agentIdEdit);
         agentName=(TextView) findViewById(R.id.agenNameEdit);
         agentAccNo=(TextView) findViewById(R.id.agenAccNoEdit);
         collectionLmt=(TextView) findViewById(R.id.collectionLimitEdit);
         accBal=(TextView) findViewById(R.id.accBalEdit);
         collectionTotal= (TextView) findViewById(R.id.collectionTotalEdit);
         unsyncBal    =   (TextView) findViewById(R.id.unsyncBalEdit);
         executeTokenService();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent pigmyCollect = new Intent(AgentBal.this,MainActivity.class);
        startActivity(pigmyCollect);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.home_menu,menu);

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId())
        {
            case android.R.id.home:
                // app icon in action bar clicked; go home
                onBackPressed();
                return true;

            case R.id.action_home_nav_btn:
                // app icon in action bar clicked; go home
                goHome();
                return true;

            case R.id.action_logout_nav_btn:
                // app icon in action bar clicked; go home
                showLogoutDialog(getResources().getString(R.string.alert_logout));
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void goHome()
    {
        Intent intent = new Intent(AgentBal.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void showLogoutDialog(String message)
    {
        final Dialog dialog = new Dialog(this);


//		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_two_btn_alert_dialog);

        dialog.setTitle(getString(R.string.logout));

        TextView textView = (TextView) dialog.findViewById(R.id.customAlert_text);

        Button cancelBtn = (Button) dialog.findViewById(R.id.cancel_btn);

        Button okBtn = (Button) dialog.findViewById(R.id.ok_btn);

        textView.setText(message);

        cancelBtn.setText(getString(R.string.no));
        okBtn.setText(getString(R.string.yes));


        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                dialog.dismiss();

            }
        });

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                Intent intent = new Intent(AgentBal.this, Login.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });

        dialog.show();

    }
    @Override
    public void processAsyncResponse(Object output) {
        String responseXmlString = (String) output;
        String agentDetailsXml = "";
        Log.e("responseXmlString", responseXmlString);
        if (Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(responseXmlString))) == 0) {
            if(isTokenService){
                isTokenService=false;
                String tokenId =  AppUtil.getXpathValue("Result/TokenID", AppUtil.buildDocument(responseXmlString));
                executeAgentBalService(tokenId);
            }else {


                agentDetailsXml = responseXmlString;
                updateData(agentDetailsXml);
            }
        } else {
            agentDetailsXml = AppUtil.getAgentDetails(preferences, this);
            updateData(agentDetailsXml);
        }









        }


        public  void updateData(String agentDetailsXml)
        {
            if (Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(agentDetailsXml))) == 0)
            {
                String agentNameValue = AppUtil.getXpathValue("Result/Details/AgentName", AppUtil.buildDocument(agentDetailsXml));
                String agentIdVal = AppUtil.getCustomerID(preferences, this);
                String agentAccNoVal = AppUtil.getXpathValue("Result/Details/ColAccNo", AppUtil.buildDocument(agentDetailsXml));
                String collectionLimitVal = AppUtil.getXpathValue("Result/Details/ColLimit", AppUtil.buildDocument(agentDetailsXml));
                String ColAccBal = AppUtil.getXpathValue("Result/Details/ColAccBal", AppUtil.buildDocument(agentDetailsXml));

                if(ColAccBal != null && Integer.parseInt(ColAccBal) >0){
                    ColAccBal = ColAccBal +" Cr";
                }
                else{
                    ColAccBal = ColAccBal +" Dr";
                }

                agentId.setText(agentIdVal);
                agentName.setText(agentNameValue);
                agentAccNo.setText(agentAccNoVal);
                collectionLmt.setText(collectionLimitVal);
                accBal.setText(ColAccBal);



            }


            Double totalCollBal = CollectionDAO.getTotalCollectionTotalBalance();
            Double totalUnsyncBal=CollectionDAO.getUnsyncTotalBalance();

            collectionTotal.setText(totalCollBal.toString());

            unsyncBal.setText(totalUnsyncBal.toString());


        }

    private void executeAgentBalService(String token)
    {


        String mobileNo = AppUtil.getMobileNumber(preferences,this);
        String imeiDeviceId = AppUtil.getDeviceIdentity(preferences,this);
        String tokenId=token;
        String agentId=AppUtil.getCustomerID(preferences,this);
        String input = "<Parameter><ProcessID>3101</ProcessID><MobileNo>"+mobileNo+"</MobileNo><IMEINo>"+imeiDeviceId+"</IMEINo><TokenID>"+tokenId+"</TokenID><AgentID>"+agentId+"</AgentID></Parameter>";
        Log.e("process id 3101",input);
        AsyncCallWS asyncCallWS = new AsyncCallWS(AgentBal.this, input,AgentBal.this);
        asyncCallWS.execute();
    }


    private void executeTokenService()
    {
        isTokenService=true;
        String mobileNo = AppUtil.getMobileNumber(preferences,this);
        String imeiDeviceId = AppUtil.getDeviceIdentity(preferences,this);
        String input = "<Parameter><ProcessID>3005</ProcessID><MobileNo>"+mobileNo+"</MobileNo><IMEINo>"+imeiDeviceId+"</IMEINo></Parameter>";
        Log.e("process id 3005",input);
        AsyncCallWS asyncCallWS = new AsyncCallWS(AgentBal.this, input,AgentBal.this);
        asyncCallWS.execute();
    }






}
