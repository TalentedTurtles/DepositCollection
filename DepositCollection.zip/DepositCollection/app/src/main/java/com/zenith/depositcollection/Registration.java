package com.zenith.depositcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.zenith.depositcollection.asyncTask.AsyncCallWS;
import com.zenith.depositcollection.asyncTask.AsyncResponse;
import com.zenith.depositcollection.util.AlertDialogueUtil;
import com.zenith.depositcollection.util.AppUtil;
import com.zenith.depositcollection.util.ConnectionMonitor;
import com.zenith.depositcollection.util.StringUtil;

public class Registration extends AppCompatActivity implements AsyncResponse {

    Button nxtBtn;
    EditText mobileNumber;
    EditText agentId;
    CheckBox terms;
    SharedPreferences preferences;
    String serviceType="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        nxtBtn = (Button)findViewById(R.id.nxtButton);
        mobileNumber=(EditText)findViewById(R.id.editMobileNo);
        terms=(CheckBox)findViewById(R.id.checkBox);
        agentId=(EditText)findViewById(R.id.editAgentId) ;
        preferences = PreferenceManager.getDefaultSharedPreferences(this);


        nxtBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(!StringUtil.hasValue(mobileNumber.getText().toString()))
                {
                    mobileNumber.setError(getString(R.string.field_err_msg));
                    return;
                }
                if(!StringUtil.hasValue(agentId.getText().toString()))
                {
                    agentId.setError(getString(R.string.field_err_msg));
                    return;
                }
                if(!terms.isChecked())
                {
                    terms.setError(getString(R.string.field_err_msg));
                    return;
                }




                callService();


            }
        });





    }


    @Override
    public void processAsyncResponse(Object output)
    {
        String responseXmlString = (String) output;
        Log.e("responseXmlString",responseXmlString);
        if (Integer.parseInt(AppUtil.getXpathValue("Result/ErrorNo", AppUtil.buildDocument(responseXmlString))) == 0)
        {
            // if  error code is 0

            if(serviceType.equalsIgnoreCase("IMEIValidate"))
            {

                int imeiStatus = Integer.parseInt(AppUtil.getXpathValue("Result/IMEIStatus", AppUtil.buildDocument(responseXmlString)));

                switch (imeiStatus)
                {
                    case 0:

//						AlertDialogueUtil.showAlertDialogue(RegisterActivity.this,"No Mobile number registered");

                        //callServiceForMobileNoValidation();

                        break;

                    case 1:

                        //callServiceForMobileNoValidation();

                        break;

                    case 2:

//						otpDialogForImeiConfirmation("Detected a new device trying to register with your mobile banking, if it is you please confirm by entering otp received to your registered mobile number below");


                        //showIMEIChangeAlert();

//						AlertDialogueUtil.showAlertDialogue(RegisterActivity.this,"Detected a new device trying to register with your mobile banking, if it is you please confirm by entering otp received to your registered mobile number below");

                        break;

                    default:

                }



            }else if(serviceType.equalsIgnoreCase("MobileRegistration"))
            {

               // otpSentDate = AppUtil.getXpathValue("Result/Date", AppUtil.buildDocument(responseXmlString));
                //gentId  = AppUtil.getXpathValue("Result/CustomerID", AppUtil.buildDocument(responseXmlString));

                AppUtil.saveMobileNumber(mobileNumber.getText().toString(),preferences,this);
                AppUtil.saveCustomerID(agentId.getText().toString(), preferences,this);

                Intent i = new Intent(Registration.this,PinConfig.class);
                startActivity(i);
                finish();



            }/*else if(serviceType.equalsIgnoreCase("otpRequest"))
            {

                validateOTP();

                showProcessingDialog();

                Toast.makeText(RegisterActivity.this, AppUtil.getXpathValue("Result/Message",AppUtil.buildDocument(responseXmlString)), Toast.LENGTH_LONG).show();


            }else if(serviceType.equalsIgnoreCase("validateOtp"))
            {
                Toast.makeText(RegisterActivity.this, getString(R.string.otp_verified_msg), Toast.LENGTH_SHORT).show();

                AppUtil.saveRegisterFlag(true, preferences);

                AppUtil.saveMobileNumber(mobileNumber.getText(),preferences, this);
                AppUtil.saveCustomerID(customerID, preferences, this);

                Intent intent = new Intent(RegisterActivity.this,PinConfigureActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }*/


        }
        else
        {
            Toast.makeText(Registration.this, AppUtil.getXpathValue("Result/Message",AppUtil.buildDocument(responseXmlString)), Toast.LENGTH_LONG).show();
        }
    }



    private void callService()
    {
        serviceType = "MobileRegistration";

//		String input = "<Parameter><ProcessID>1001</ProcessID><MobileNo>" + mobileNumber + "</MobileNo><Parameter>";

        String input = "<Parameter><ProcessID>3001</ProcessID><MobileNo>"+mobileNumber.getText().toString()+"</MobileNo></Parameter>";
        Log.e("process id 3001",input);
        AsyncCallWS asyncCallWS = new AsyncCallWS(Registration.this, input,Registration.this);
        asyncCallWS.execute();
    }
    private void callServiceForOTP()
    {
        if(ConnectionMonitor.isConnectingToInternet(Registration.this))
        {

            String customerID = AppUtil.getCustomerID(preferences, this);

            String mobileNumber = AppUtil.getMobileNumber(preferences,this);

            serviceType = "otpRequest";

            String inputForOtpToStopCheque = "<Parameter> <ProcessID>1014</ProcessID><CustID>"+customerID+"</CustID><MobileNo>"+mobileNumber+"</MobileNo><ResendOTP>N</ResendOTP></Parameter>";
            Log.e("process id 1014",inputForOtpToStopCheque);

            AsyncCallWS asyncCallWS = new AsyncCallWS(Registration.this, inputForOtpToStopCheque, Registration.this);
            asyncCallWS.execute();

        }else
        {
            AlertDialogueUtil.showOkAlertDialog(Registration.this,getString(R.string.no_internet_body_text));
        }

    }

}
