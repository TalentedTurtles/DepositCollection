package com.zenith.depositcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.zenith.depositcollection.db.Collection;
import com.zenith.depositcollection.db.CollectionDAO;
import com.zenith.depositcollection.db.Pigmy;
import com.zenith.depositcollection.db.PigmyDAO;
import com.zenith.depositcollection.util.AppUtil;
import com.zenith.depositcollection.util.StringUtil;

import java.util.ArrayList;
import java.util.Date;

public class PigmyCollect extends AppCompatActivity {

    Integer selectedPAccount;
    EditText collectDateEdit;
    EditText custNameEdit;
    EditText accountNoEdit;
    EditText accountBalEdit;
    EditText lastCollEdit;
    EditText collectionAmtEdit;
    EditText unSyncBalEdit;
    Button submitBtn;
    Double prevBal=0.0;
    Double prevUnsyncBal=0.0;
    Double prevCollAmt=0.0;
    SharedPreferences preferences;
    Pigmy selectedPigmyAcc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = PreferenceManager.getDefaultSharedPreferences(this);

        setContentView(R.layout.activity_pigmy_collect);
        collectDateEdit=(EditText)findViewById(R.id.collectDateEdit) ;
        custNameEdit=(EditText)findViewById(R.id.custNameEdit);
        accountNoEdit=(EditText)findViewById(R.id.accNoEdit);
        accountBalEdit=(EditText)findViewById(R.id.accBal2Edit);
        lastCollEdit=(EditText)findViewById(R.id.lastCollectDateEdit);
        collectionAmtEdit=(EditText)findViewById(R.id.collectionAmtEdit);
        unSyncBalEdit=(EditText)findViewById(R.id.unsyncBalEdit);

        submitBtn=(Button)findViewById(R.id.submitBtn);
            selectedPAccount = getIntent().getIntExtra("account_no",0);

           ArrayList<Pigmy> pList = (ArrayList<Pigmy>) PigmyDAO.getAllAccountTransactionsByAccountNo(selectedPAccount,"asc");
          if(pList.size() > 0)
          {
              selectedPigmyAcc=  pList.get(0);
             Date d = new Date();
             collectDateEdit.setText(StringUtil.DateToString(d));

              custNameEdit.setText(selectedPigmyAcc.getCustName());
              accountNoEdit.setText(Integer.toString(selectedPigmyAcc.getAccountNo()));
              accountBalEdit.setText(Double.toString(selectedPigmyAcc.getBal()));
              lastCollEdit.setText(selectedPigmyAcc.getLastCollDate());
              collectionAmtEdit.setText("0.0");
              Double unsyncBal = CollectionDAO.getCollectionUnsyncBalance(selectedPigmyAcc.getAccountNo(),"asc");
              unSyncBalEdit.setText(Double.toString(unsyncBal));

              prevBal = selectedPigmyAcc.getBal();
              prevUnsyncBal=unsyncBal;
              prevCollAmt=selectedPigmyAcc.getCollectionAmt();

          }

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                updateTransaction();



                Toast.makeText(getApplicationContext(),"Collection Saved Successfully",Toast.LENGTH_SHORT).show();

                showprintDialog("");
            }
        });
    }

    public  void updateTransaction()
    {
       Pigmy p = new Pigmy();
       p.setAccountNo(selectedPAccount);
       p.setLastCollDate(collectDateEdit.getText().toString());
       p.setSyncStatus("N");
       Double collAmt = Double.parseDouble( collectionAmtEdit.getText().toString());
       p.setCollectionAmt(prevCollAmt+collAmt);
       p.setBal(prevBal+collAmt);
      // p.setUnsyncBal(prevUnsyncBal+collAmt);



       Long rowId = PigmyDAO.updatePigmyTransaction(p);
       //Generate Receipt and create collection
      String dm =  StringUtil.DateToStringDM(new Date());
      boolean isFirst = isFirstReceiptForTheDay();
      if(isFirst)
      {
          AppUtil.saveReceiptSNo("0",preferences,this);
      }

         String prevNo = AppUtil.getReceiptSNo(preferences,this);
         Integer receiptNo = Integer.parseInt(prevNo)+1;
         AppUtil.saveReceiptSNo(receiptNo.toString(),preferences,this);
         String generatedRNo = dm+receiptNo;

        Collection c = new Collection();
        c.setAccountNo(selectedPigmyAcc.getAccountNo());
        c.setReceiptNo(Integer.parseInt(generatedRNo));
        c.setCollectionAmt(collAmt);
        c.setLastCollDate(collectDateEdit.getText().toString());
        c.setSyncStatus("NP");
        c.setSubSysCode(selectedPigmyAcc.getSubSysCode());

        CollectionDAO.insertCollection(c);



       Log.i("Updated Successfully", String.valueOf(rowId));

    }


    private boolean isFirstReceiptForTheDay()
    {
        Date d = new Date();
        String today =   StringUtil.DateToString(d);

       return CollectionDAO.getAllCollectionsByDate(today,"asc");

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent pigmyCollect = new Intent(PigmyCollect.this,Dashboard.class);

        startActivity(pigmyCollect);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.home_menu,menu);

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId())
        {
            case android.R.id.home:
                // app icon in action bar clicked; go home
                onBackPressed();
                return true;

            case R.id.action_home_nav_btn:
                // app icon in action bar clicked; go home
                goHome();
                return true;

            case R.id.action_logout_nav_btn:
                // app icon in action bar clicked; go home
                showLogoutDialog(getResources().getString(R.string.alert_logout));
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void goHome()
    {
        Intent intent = new Intent(PigmyCollect.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void showprintDialog(String message)
    {
        final Dialog dialog = new Dialog(this);


//		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_two_btn_alert_dialog);
        dialog.setCancelable(false);
        //dialog.setTitle(getString(R.string.logout));

        TextView textView = (TextView) dialog.findViewById(R.id.customAlert_text);

        Button cancelBtn = (Button) dialog.findViewById(R.id.cancel_btn);

        Button okBtn = (Button) dialog.findViewById(R.id.ok_btn);

        //textView.setText(message);

        okBtn.setText(getString(R.string.prrintBtn));

        cancelBtn.setText(getString(R.string.cancel));


        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(PigmyCollect.this, Dashboard.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                Intent intent = new Intent(PigmyCollect.this, Dashboard.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });

        dialog.show();

    }
    private void showLogoutDialog(String message)
    {
        final Dialog dialog = new Dialog(this);


//		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_two_btn_alert_dialog);

        dialog.setTitle(getString(R.string.logout));

        TextView textView = (TextView) dialog.findViewById(R.id.customAlert_text);

        Button cancelBtn = (Button) dialog.findViewById(R.id.cancel_btn);

        Button okBtn = (Button) dialog.findViewById(R.id.ok_btn);

        textView.setText(message);

        cancelBtn.setText(getString(R.string.no));
        okBtn.setText(getString(R.string.yes));


        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


               dialog.dismiss();
            }
        });

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                Intent pigmyCollect = new Intent(PigmyCollect.this,Login.class);
                // pigmyCollect.
                startActivity(pigmyCollect);
                finish();

            }
        });

        dialog.show();

    }


}
