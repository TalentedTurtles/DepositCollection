package com.zenith.depositcollection.util;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;


import com.zenith.depositcollection.R;
import com.zenith.depositcollection.model.User;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.List;
import java.util.Locale;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import  com.zenith.depositcollection.R;
public class AppUtil {


        static XPath xpath;

        private static String accountNumber = "";

        private static String mobileNumber = "";



        public static String language_code = "";

        static Context context;



        /**
         * LocaleChange : <<Description>>
         * @param context
         */
        public static void LocaleChange(Context context)
        {
                Resources res = context.getResources();
                // Change locale settings in the app.
                DisplayMetrics dm = res.getDisplayMetrics();
                android.content.res.Configuration conf = res.getConfiguration();
                conf.locale = new Locale(language_code.toLowerCase());
                res.updateConfiguration(conf, dm);
        }

        /**
         * saveLanguageCode : <<Description>>
         * @param language
         * @param pref
         */
        public static void saveLanguageCode(String language, SharedPreferences pref)
        {
            if (pref != null)
            {
                SharedPreferences.Editor editor = pref.edit();
                editor.putString(AppConstants.LANGUAGE_CODE, language);
                editor.commit();
            }
        }

        /**
         * getLanguageCode : <<Description>>
         * @param preferences
         * @return
         */
        public static String getLanguageCode(SharedPreferences preferences)
        {
            if (preferences != null && preferences.contains(AppConstants.LANGUAGE_CODE))
            {
                return preferences.getString(AppConstants.LANGUAGE_CODE, "");
            }
            return "";
        }


        /**
         * saveRegisterFlag : <<Description>>
         * @param flag
         * @param pref
         */
        public static void saveRegisterFlag(boolean flag, SharedPreferences pref)
        {
            if (pref != null)
            {
                SharedPreferences.Editor editor = pref.edit();
                editor.putBoolean(AppConstants.REGISTER_FLAG, flag);
                editor.commit();
            }
        }

        /**
         * getRegisterFlag : <<Description>>
         * @param preferences
         * @return
         */
        public static boolean getRegisterFlag(SharedPreferences preferences)
        {
            if (preferences != null && preferences.contains(AppConstants.REGISTER_FLAG))
            {
                return preferences.getBoolean(AppConstants.REGISTER_FLAG, false);
            }
            return false;
        }

        /**
         * savePinNumberStatus : <<Description>>
         * @param pinNo
         * @param pref
         */
        public static void savePinNumberStatus(boolean pinNo, SharedPreferences pref)
        {
            if (pref != null)
            {
                SharedPreferences.Editor editor = pref.edit();
                editor.putBoolean(AppConstants.PIN_NUMBER, pinNo);
                editor.commit();
            }
        }


        /**
         * saveCustomerName : <<Description>>
         * @param customerName
         * @param pref
         * @param context
         */
        public static void saveCustomerName(String customerName, SharedPreferences pref, Context context)
        {
            if (pref != null)
            {
                SharedPreferences.Editor editor = pref.edit();

                editor.putString(AppConstants.CUSTOMER_NAME, encryptText(customerName,context));

                editor.commit();



            }
        }

        /**
         * getCustomerName : <<Description>>
         * @param preferences
         * @return
         */
        public static String getCustomerName(SharedPreferences preferences,Context context)
        {
            if (preferences != null && preferences.contains(AppConstants.CUSTOMER_NAME))
            {
                return decryptText(preferences.getString(AppConstants.CUSTOMER_NAME, ""),context);
            }
            return "";
        }

        public static void saveMobileNumber(String mobileNo, SharedPreferences pref, Context context)
        {
            if (pref != null)
            {
                SharedPreferences.Editor editor = pref.edit();
                editor.putString(AppConstants.MOBILE_NUMBER, encryptText(mobileNo, context));
                editor.commit();
            }
        }
    public static void saveMpinNumber(String mpin, SharedPreferences pref, Context context)
    {
        if (pref != null)
        {
            SharedPreferences.Editor editor = pref.edit();
            editor.putString(AppConstants.MPIN, encryptText(mpin, context));
            editor.commit();
        }
    }


    public static void saveDeviceIdentity(String deiceId, SharedPreferences pref, Context context)
    {
        if (pref != null)
        {
            SharedPreferences.Editor editor = pref.edit();
            editor.putString(AppConstants.DEICE_ID, encryptText(deiceId, context));
            editor.commit();
        }
    }


    public static void saveToken(String token, SharedPreferences pref, Context context)
    {
        if (pref != null)
        {
            SharedPreferences.Editor editor = pref.edit();
            editor.putString(AppConstants.TOKEN, encryptText(token, context));
            editor.commit();
        }
    }


    public static void saveAgentDetails(String agentDetails, SharedPreferences pref, Context context)
    {
        if (pref != null)
        {
            SharedPreferences.Editor editor = pref.edit();
            editor.putString(AppConstants.AGENT_DETAILS, encryptText(agentDetails, context));
            editor.commit();
        }
    }
    public static String getAgentDetails(SharedPreferences preferences,Context context)
    {
        if (preferences != null && preferences.contains(AppConstants.AGENT_DETAILS))
        {
            return decryptText(preferences.getString(AppConstants.AGENT_DETAILS, ""),context);
        }
        return "";
    }

    public static String getMobileNumber(SharedPreferences preferences,Context context)
        {
            if (preferences != null && preferences.contains(AppConstants.MOBILE_NUMBER))
            {
                return decryptText(preferences.getString(AppConstants.MOBILE_NUMBER, ""),context);
            }
            return "";
        }

       public static String getMpinNumber(SharedPreferences preferences,Context context)
        {
        if (preferences != null && preferences.contains(AppConstants.MPIN))
        {
            return decryptText(preferences.getString(AppConstants.MPIN, ""),context);
        }
        return "";
         }

    public static String getDeviceIdentity(SharedPreferences preferences,Context context)
    {
        if (preferences != null && preferences.contains(AppConstants.DEICE_ID))
        {
            return decryptText(preferences.getString(AppConstants.DEICE_ID, ""),context);
        }
        return "";
    }

    public static String getToken(SharedPreferences preferences,Context context)
    {
        if (preferences != null && preferences.contains(AppConstants.TOKEN))
        {
            return decryptText(preferences.getString(AppConstants.TOKEN, ""),context);
        }
        return "";
    }





    public static void saveCustomerID(String customerID, SharedPreferences pref, Context context)
        {
            if (pref != null)
            {
                SharedPreferences.Editor editor = pref.edit();
                editor.putString(AppConstants.CUSTOMER_ID, encryptText(customerID, context));
                editor.commit();
            }
        }

        public static String getCustomerID(SharedPreferences preferences, Context context)
        {
            if (preferences != null && preferences.contains(AppConstants.CUSTOMER_ID))
            {
                return decryptText(preferences.getString(AppConstants.CUSTOMER_ID, ""), context);
            }
            return "";
        }


    public static void saveReceiptSNo(String receiptNo, SharedPreferences pref, Context context)
    {
        if (pref != null)
        {
            SharedPreferences.Editor editor = pref.edit();
            editor.putString(AppConstants.PRE_RECEIPT_NO, encryptText(receiptNo, context));
            editor.commit();
        }
    }

    public static String getReceiptSNo(SharedPreferences preferences, Context context)
    {
        if (preferences != null && preferences.contains(AppConstants.PRE_RECEIPT_NO))
        {
            return decryptText(preferences.getString(AppConstants.PRE_RECEIPT_NO, ""), context);
        }
        return "";
    }



    public static void saveAgentUnSyncCollBal(String agentCollectionAmt, SharedPreferences pref, Context context)
    {
        if (pref != null)
        {
            SharedPreferences.Editor editor = pref.edit();
            editor.putString(AppConstants.AGENT_COLLECTION_AMT_UNSYNC, encryptText(agentCollectionAmt, context));
            editor.commit();
        }
    }

    public static String getAgentUnSyncCollBal(SharedPreferences preferences, Context context)
    {
        if (preferences != null && preferences.contains(AppConstants.AGENT_COLLECTION_AMT_UNSYNC))
        {
            return decryptText(preferences.getString(AppConstants.AGENT_COLLECTION_AMT_UNSYNC, "0"), context);
        }
        return "";
    }

    public static void saveAgentCollBal(String agentCollectionAmt, SharedPreferences pref, Context context)
    {
        if (pref != null)
        {
            SharedPreferences.Editor editor = pref.edit();
            editor.putString(AppConstants.AGENT_COLLECTION_AMT, encryptText(agentCollectionAmt, context));
            editor.commit();
        }
    }

    public static String getAgentCollBal(SharedPreferences preferences, Context context)
    {
        if (preferences != null && preferences.contains(AppConstants.AGENT_COLLECTION_AMT))
        {
            return decryptText(preferences.getString(AppConstants.AGENT_COLLECTION_AMT, "0"), context);
        }
        return "";
    }

        public static void saveLoginUserInfo(String customerInfo, SharedPreferences pref, Context context)
        {
            if (pref != null)
            {
                SharedPreferences.Editor editor = pref.edit();
                editor.putString(AppConstants.LOGIN_USER_INFO, encryptText(customerInfo, context));
                editor.commit();
            }
        }

        public static String getLoginUserInfo(SharedPreferences preferences, Context context)
        {
            if (preferences != null && preferences.contains(AppConstants.LOGIN_USER_INFO))
            {
                return decryptText(preferences.getString(AppConstants.LOGIN_USER_INFO, ""), context);
            }
            return "";
        }

        public static void saveFundTransferStatus(String fundTransferStatus, SharedPreferences pref, Context context)
        {
            if (pref != null)
            {
                SharedPreferences.Editor editor = pref.edit();
                editor.putString(AppConstants.FUND_TRANSFER_ENABLED_STATUS, encryptText(fundTransferStatus, context));
                editor.commit();
            }
        }

        public static String getFundTransferStatus(SharedPreferences preferences, Context context)
        {
            if (preferences != null && preferences.contains(AppConstants.FUND_TRANSFER_ENABLED_STATUS))
            {
                try
                {
                    return decryptText(preferences.getString(AppConstants.FUND_TRANSFER_ENABLED_STATUS, ""), context);
                }catch (ClassCastException cce)
                {
                    return "N";
                }

            }
            return "N";
    }

        public static void saveSessionID(String sessionID, SharedPreferences pref, Context context)
        {
            if (pref != null)
            {
                SharedPreferences.Editor editor = pref.edit();
                editor.putString(AppConstants.SESSION_ID, encryptText(sessionID, context));
                editor.commit();
            }
        }

    public static void saveProfilePath(String path, SharedPreferences pref)
    {
        if (pref != null)
        {
            SharedPreferences.Editor editor = pref.edit();
            editor.putString(AppConstants.PROFILE_IMAGE, path);
            editor.commit();
        }
    }

        public static String getSessionID(SharedPreferences preferences, Context context)
        {
            if (preferences != null && preferences.contains(AppConstants.SESSION_ID))
            {
                return decryptText(preferences.getString(AppConstants.SESSION_ID, ""), context);
            }
            return "";
        }


        /**
         * getPinNumber : <<Description>>
         * @param preferences
         * @return
         */
        public static boolean getPinNumberStatus(SharedPreferences preferences)
        {
            if (preferences != null && preferences.contains(AppConstants.PIN_NUMBER))
            {
                try
                {
                    return preferences.getBoolean(AppConstants.PIN_NUMBER, false);
                }catch (ClassCastException cce)
                {
                    return false;
                }

            }
            return false;
        }

        /**

        public static void setActionBarTitle(Activity activity,String titleText)
        {
            activity.getActionBar().setDisplayShowCustomEnabled(true);
            activity.getActionBar().setDisplayShowTitleEnabled(false);
            LayoutInflater inflator = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View actionBarView  = inflator.inflate(R.layout.custom_actionbar_title, null);

            ActionBar.LayoutParams params = new ActionBar.LayoutParams(
                    ActionBar.LayoutParams.WRAP_CONTENT, ActionBar.LayoutParams.MATCH_PARENT,
                    Gravity.CENTER);

            TextView title = (TextView)actionBarView.findViewById(R.id.Ac);
            title.setText(titleText);

            activity.getActionBar().setCustomView(actionBarView, params);
        }*/

        public static Document buildDocument(String xml)
        {
            InputSource xmlDocument = new InputSource(new StringReader(xml));
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db;
            Document document = null;
            try
            {
                db = dbf.newDocumentBuilder();
                document = db.parse(xmlDocument);
            }
            catch (ParserConfigurationException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            catch (SAXException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            catch (IOException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return document;

        }

        public static User getUserInfo(SharedPreferences preferences, Context context)
        {
            User user = null;

            if (preferences != null && preferences.contains(AppConstants.LOGIN_USER_INFO))
            {
                String loginUserInfo = getLoginUserInfo(preferences, context);

                user = new User(loginUserInfo);
            }



            return user;

        }

        /**
         * getXpathValue : <<Description>>
         * @param expression
         * @param doc
         * @return
         */
        public static String getXpathValue(String expression, Document doc)
        {
            String xPathValue = "";
            if (doc != null)
            {

                try
                {
                    xPathValue = getXpath().compile(expression).evaluate(doc);
                }
                catch (XPathExpressionException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            return xPathValue;

        }


        /**
         * @param expression
         * @param doc
         * @return
         */
        public static String[] getXpathValues(String expression, Document doc)
        {

            String[] values = null;
            try
            {
                NodeList nodeList1 = (NodeList) getXpath().compile(expression).evaluate(doc,
                        XPathConstants.NODESET);
                values = new String[nodeList1.getLength()];
                for (int i = 0; i < nodeList1.getLength(); i++)
                {

                    if (nodeList1.item(i).getFirstChild() != null)
                    {
                        values[i] = nodeList1.item(i).getFirstChild().getNodeValue();
                    }
                    else
                    {
                        values[i] =  "";
                    }

                }
            }
            catch (XPathExpressionException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return values;

        }

        public static NodeList getXpathNodeList(String expression, Document doc)
        {

            NodeList nodeList = null;
            try
            {
                nodeList = (NodeList) getXpath().compile(expression).evaluate(doc,XPathConstants.NODESET);
    //			nodeList = (NodeList) getXpath().evaluate(expression,doc,XPathConstants.NODESET);

            }
            catch (XPathExpressionException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return nodeList;

        }


        /**
         * @param expression
         * @param doc
         * @return
         */
        public static String[] getXpathWithAttributeValues(String expression, Document doc)
        {
         // get the attribute value(hear we are using to get the header value also from xml
            String[] values = null;
            try
            {
                NodeList nodeList1 = (NodeList) getXpath().compile(expression).evaluate(doc,
                        XPathConstants.NODESET);
                values = new String[nodeList1.getLength()];
                for (int i = 0; i < nodeList1.getLength(); i++)
                {

                    values[i] = nodeList1.item(i).getNodeValue();
                }
            }
            catch (XPathExpressionException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return values;

        }

        public static XPath getXpath()
        {
            if (xpath == null)
            {
                xpath = XPathFactory.newInstance().newXPath();
            }
            return xpath;
        }


        public static void saveAccountNumber(String accNumber)
        {
             accountNumber = accNumber;
        }

        public static String getAccountNumber()
        {
            return accountNumber;

        }





    public static String[] getXpathValues(NodeList nodeList)
    {

        String[] values = null;
        try
        {

            int nodeLength = getValidLength(nodeList);
            values = new String[nodeLength];

            int k =0 ;
            if(k > nodeLength)
            {
                //Do't do any thing
            }
            else
            {
                for (int i = 0; i < nodeList.getLength(); i++)
                {
                    if(nodeList.item(i).getNodeType() == Node.ELEMENT_NODE )
                    {


                        if (nodeList.item(i).getFirstChild() != null)
                        {
                            values[k] = nodeList.item(i).getFirstChild().getNodeValue();
                        }
                        else
                        {
                            values[k] =  "";
                        }
                        k++;
                    }



                }
            }

        }
        catch (Exception e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return values;

    }

    private static  int getValidLength(NodeList nodeList)
    {
        int j =0 ;
        for (int i = 0; i < nodeList.getLength(); i++) {
            if (nodeList.item(i).getNodeType() == Node.ELEMENT_NODE) {
             j++;
            }
        }
        return j;
    }


    public static String nodeToString(Node node) {
        StringWriter sw = new StringWriter();
        try {
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            t.transform(new DOMSource(node), new StreamResult(sw));
        } catch (TransformerException te) {
            System.out.println("nodeToString Transformer Exception");
        }
        return sw.toString();
    }

    /*Mobile Number Utils*/

    public static boolean isMobileNoAvailable(Context context)
    {
        boolean isMobileNoAvailable = false;

        TelephoneInfo telephoneInfo = TelephoneInfo.getInstance(context);

        isMobileNoAvailable =  telephoneInfo.isSIM1Ready() || telephoneInfo.isSIM2Ready();

        return  isMobileNoAvailable;
    }
    public static String getDeviceId(Context context)
    {

        TelephoneInfo telephoneInfo = TelephoneInfo.getInstance(context);



        return  telephoneInfo.getImsiSIM1();
    }

    public static boolean isMobileDualSimPhone(Context context)
    {
        boolean isDualSim = false;

        TelephoneInfo telephoneInfo = TelephoneInfo.getInstance(context);

        isDualSim = telephoneInfo.isDualSIM();

        return isDualSim;
    }


    public static String encryptText(String input, Context context)
    {

        String encryptedText = "";

        String prefKey = context.getResources().getString(R.string.pref_key);

        CryptUtilsNew cryptUtils =  new CryptUtilsNew();

        try
        {
            encryptedText = cryptUtils.encrypt(input,prefKey);

            return encryptedText;

        } catch (Exception e)
        {
            e.printStackTrace();

            return  encryptedText;
        }

    }

    public static String decryptText(String input, Context context)
    {
        String decrypedText = "";

        String prefKey = context.getResources().getString(R.string.pref_key);

        CryptUtilsNew cryptUtils =  new CryptUtilsNew();

        try
        {
            decrypedText =  cryptUtils.decrypt(input,prefKey);

            return decrypedText;

        } catch (Exception e) {
            e.printStackTrace();

            return decrypedText;
        }


    }

}

