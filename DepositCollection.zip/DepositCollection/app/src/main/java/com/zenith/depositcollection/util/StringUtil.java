package com.zenith.depositcollection.util;

import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Class : <<Description>>
 * @version $ Revision: 1.0 $
 * @author mithunr
 */
public class StringUtil
{
	/**
	 * hasValue : <<Description>>
	 * 
	 * @param value
	 * @return
	 */
	public static boolean hasValue(String value)
	{
		boolean hasValue = false;
		if (value != null && value.trim().length() > 0)
		{
			hasValue = true;
		}
		return hasValue;
	}

	/**
	 * DateToString : <<Description>>
	 * 
	 * @param date
	 * @return
	 */
	public static String DateToString(Date date)
	{
		SimpleDateFormat parser = new SimpleDateFormat("dd/MM/yyyy");
		try
		{
			if (date != null && hasValue(date.toString()))
			{
				return parser.format(date);
			}
			else
			{
				return null;
			}
		}
		catch (Exception err)
		{
			return date.toString();
		}
	}
	/**
	 * DateToString : <<Description>>
	 *
	 * @param date
	 * @return
	 */
	public static String DateToStringTime(Date date)
	{
		SimpleDateFormat parser = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
		try
		{
			if (date != null && hasValue(date.toString()))
			{
				return parser.format(date);
			}
			else
			{
				return null;
			}
		}
		catch (Exception err)
		{
			return date.toString();
		}
	}

	/**
	 * DateToString : <<Description>>
	 *
	 * @param date
	 * @return
	 */
	public static String DateToStringDM(Date date)
	{
		SimpleDateFormat parser = new SimpleDateFormat("ddMMyy");
		try
		{
			if (date != null && hasValue(date.toString()))
			{
				return parser.format(date);
			}
			else
			{
				return null;
			}
		}
		catch (Exception err)
		{
			return date.toString();
		}
	}




	public static Date StringToDate(String dateString)
	{
		SimpleDateFormat parser = new SimpleDateFormat("dd/MM/yyyy");
		Date date = null;
		try 
		{

			date = parser.parse(dateString);

		} catch (ParseException e)
		{
			e.printStackTrace();
		}
		return date;

	}
	
	public static boolean isValidateDob(Date dob)
	{
		boolean flag ;
		Date c_date = new Date();
		try {
		
		if (c_date.getTime() > dob.getTime() ) {
			flag = true;
		}
		else
		{
			flag = false;
		}
		
		} 
		catch (Exception e) 
		{
			flag = false;
		}
		
		/*long diffInMillisec = c_date.getTime() - dob.getTime();
		long diffInSec = TimeUnit.MILLISECONDS.toSeconds(diffInMillisec);
		long seconds = diffInSec % 60;
		diffInSec /= 60;
		long minutes = diffInSec % 60;
		diffInSec /= 60;
		long hours = diffInSec % 24;
		diffInSec /= 24;
		long days = diffInSec;*/
		
		return flag;
	}

    public static String DateToStringFrmt(Date date)
    {
        SimpleDateFormat parser = new SimpleDateFormat("dd/MM/yyyy");
        try
        {
            if (date != null && hasValue(date.toString()))
            {
                return parser.format(date);
            }
            else
            {
                return null;
            }
        }
        catch (Exception err)
        {
            return date.toString();
        }
    }

    public static Date StringToDateFrmt(String dateString)
    {
        SimpleDateFormat parser = new SimpleDateFormat("dd/MM/yyyy");
        Date date = null;
        try
        {

            date = parser.parse(dateString);

        } catch (ParseException e)
        {
            e.printStackTrace();
        }
        return date;

    }

	public static boolean isDocExpiryDateIsValid(Date dob)
	{
		boolean flag ;
		try
		{
		Date c_date = new Date();
		if (c_date.getTime() > dob.getTime() ) 
		{
			flag = false;
		}
		else
		{
			flag = true;
		}
		} 
		catch (Exception e) 
		{
			flag = false;
			//
		}
		
		/*long diffInMillisec = c_date.getTime() - dob.getTime();
		long diffInSec = TimeUnit.MILLISECONDS.toSeconds(diffInMillisec);
		long seconds = diffInSec % 60;
		diffInSec /= 60;
		long minutes = diffInSec % 60;
		diffInSec /= 60;
		long hours = diffInSec % 24;
		diffInSec /= 24;
		long days = diffInSec;*/
		
		return flag;
	}
	
	
	/**
	 * getDiffYears : <<Description>> 
	 * @param first
	 * @param last
	 * @return
	 */
	public static int getDiffYears(Date first, Date last)
	{
		Calendar a = getCalendar(first);
		Calendar b = getCalendar(last);
		int diff = b.get(Calendar.YEAR) - a.get(Calendar.YEAR);
		if (a.get(Calendar.MONTH) > b.get(Calendar.MONTH)
				|| (a.get(Calendar.MONTH) == b.get(Calendar.MONTH) && a.get(Calendar.DAY_OF_MONTH) > b
						.get(Calendar.DAY_OF_MONTH)))
		{
			diff--;
		}
		return diff;
	}

	public static long getDiffInMin(String  first, Date last)
	{
		
		SimpleDateFormat parser =new SimpleDateFormat("yyyyMMddHHmm Z");
		Date f_date = null;
		Date l_date = null;
		try 
		{

			f_date = parser.parse(first);

		} catch (ParseException e)
		{
			e.printStackTrace();
		}
		
		long diffInMillisec = last.getTime() - f_date.getTime();
		long diffInSec = TimeUnit.MILLISECONDS.toSeconds(diffInMillisec);
		long seconds = diffInSec % 60;
		diffInSec /= 60;
		long minutes = diffInSec % 60;
		diffInSec /= 60;
		long hours = diffInSec % 24;
		diffInSec /= 24;
		long days = diffInSec;
		
		return minutes;
	}
	
	/**
	 * getCalendar : <<Description>> 
	 * @param date
	 * @return
	 */
	public static Calendar getCalendar(Date date)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal;
	}

	public static String generateRandomPinNumber()
	{
		//generate a 4 digit integer 1000 <10000
		int randomPIN = (int)(Math.random()*9000)+1000;

		//Store integer in a string
		return String.valueOf(randomPIN);
	}
	public static String getDeviceID(Context context){

		String deviceId = null;

		TelephonyManager teleService = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		try
		{
			if (teleService != null)
			{
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
					deviceId = teleService.getDeviceId(0);
				}else
				{
					deviceId = teleService.getDeviceId();
				}

			}if(deviceId==null)
		{
			deviceId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
		}

		}catch (Exception e)
		{
			e.printStackTrace();
		}

		return deviceId;
	}

	public static String currentDateTime()
	{

		SimpleDateFormat timeFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a", Locale.US);

		Date date = new Date();
		try
		{
			if (date != null && hasValue(date.toString()))
			{
				return timeFormat.format(date);
			}
			else
			{
				return null;
			}
		}
		catch (Exception err)
		{
			return date.toString();
		}


	}

	public static String getOtpFromMsg(String message)
	{
		Pattern p = Pattern.compile("\\b\\d{6}\\b");
		Matcher m = p.matcher(message);
		String code = "";
		while (m.find()) {
			code = m.group(0);
		}
		return code;
	}
	
}
